//! Tauri command handlers, split into logical submodules.
//!
//! Architecture:
//! - `helpers` — shared utilities (run_cmd, run_privileged, validation, etc.)
//! - `config_cmd` — config CRUD commands
//! - `health` — health check + system status
//! - `snapshots` — snapper snapshot commands
//! - `sync_cmd` — rsync sync orchestration
//! - `boot` — boot info & validation
//! - `rollback` — btrfs rollback
//! - `timer` — systemd timer install/uninstall
//! - `headless` — CLI/systemd headless sync (no Tauri runtime)

pub mod helpers;
mod config_cmd;
mod health;
mod snapshots;
mod sync_cmd;
mod boot;
mod rollback;
mod timer;
mod headless;
mod cleanup;
mod install;

// Re-export all Tauri commands so lib.rs can use `commands::*`
pub use config_cmd::*;
pub use health::{get_health, get_system_status};
pub use snapshots::*;
pub use sync_cmd::{run_sync, get_sync_status, get_sync_log, get_btrfs_usage, get_system_monitor, verify_backup};
pub use boot::get_boot_info;
pub use rollback::rollback_snapshot;
pub use timer::*;
pub use headless::run_sync_headless;
pub use cleanup::{scan_cleanup, cancel_scan, delete_cleanup_paths, get_cleanup_dir_contents};
pub use install::{get_integration_status, install_system_integration, uninstall_system_integration};
