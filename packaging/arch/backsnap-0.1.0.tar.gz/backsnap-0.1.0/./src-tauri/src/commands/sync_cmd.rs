//! NVMe sync commands: rsync-based subvolume sync, boot sync, EFI patching.

use super::helpers::*;
use crate::config::AppConfig;
use std::fs;
use std::io::{BufRead, BufReader, Read};
use std::process::Command;
use std::sync::atomic::Ordering;
use std::time::Instant;

// ─── Sync Context ─────────────────────────────────────────────

#[derive(Debug)]
pub(super) struct SyncContext {
    pub backup_dev: String,
    pub mount_base: String,
    pub direction: String,
    pub is_primary_boot: bool,
}

pub(super) fn detect_sync_direction(c: &AppConfig) -> Result<SyncContext, String> {
    if c.disks.primary_uuid.is_empty() || c.disks.backup_uuid.is_empty() {
        return Err(
            "Disks nicht konfiguriert. Bitte unter Einstellungen Primary und Backup Disk wählen."
                .to_string(),
        );
    }

    let current_uuid = get_boot_uuid();
    let is_primary_boot = current_uuid == c.disks.primary_uuid;

    let (backup_uuid, direction) = if is_primary_boot {
        (
            c.disks.backup_uuid.clone(),
            format!("{} -> {}", c.disks.primary_label, c.disks.backup_label),
        )
    } else if current_uuid == c.disks.backup_uuid {
        return Err(
            "SICHERHEITSSPERRE: System ist vom Backup gebootet! \
             Ein Sync würde die Primary-Disk mit älteren Backup-Daten überschreiben. \
             Bitte vom Primary-Disk booten, um einen Sync durchzuführen."
                .to_string(),
        );
    } else {
        return Err(format!(
            "Boot-UUID {} entspricht weder Primary ({}) noch Backup ({}). Bitte Einstellungen prüfen.",
            current_uuid, c.disks.primary_uuid, c.disks.backup_uuid
        ));
    };

    let blkid = run_cmd("blkid", &["-U", &backup_uuid]);
    if !blkid.success || blkid.stdout.trim().is_empty() {
        return Err(format!(
            "Backup-Disk nicht gefunden (UUID: {}). Ist sie eingebaut?",
            backup_uuid
        ));
    }
    let backup_dev = blkid.stdout.trim().to_string();

    Ok(SyncContext {
        backup_dev,
        mount_base: c.sync.mount_base.clone(),
        direction,
        is_primary_boot,
    })
}

// ─── Mount / Unmount ──────────────────────────────────────────

pub(super) fn mount_subvol(dev: &str, mnt: &str, subvol: &str, mount_opts: &str) -> Result<(), String> {
    let _ = run_privileged("mkdir", &["-p", mnt]);

    let check = run_cmd("mountpoint", &["-q", mnt]);
    if check.success {
        let findmnt = run_cmd("findmnt", &[mnt, "-o", "SOURCE,FSROOT", "-n"]);
        if findmnt.success {
            let out = findmnt.stdout.trim().to_string();
            let has_correct_subvol = out.contains(&format!("[/{}]", subvol))
                || out.contains(&format!("/{}", subvol));
            let has_correct_dev = out.contains(dev);
            if has_correct_subvol && has_correct_dev {
                return Ok(());
            }
        }
        safe_umount(mnt);
        let _ = run_privileged("mkdir", &["-p", mnt]);
    }

    let opts = format!("subvol=/{},{}", subvol, mount_opts);
    let result = run_privileged("mount", &["-o", &opts, dev, mnt]);
    if !result.success {
        return Err(format!("mount {} -> {}: {}", dev, mnt, result.stderr));
    }
    Ok(())
}

pub(super) fn safe_umount(mnt: &str) {
    let result = run_privileged("umount", &[mnt]);
    if !result.success {
        let _ = run_privileged("umount", &["-l", mnt]);
    }
    let check = run_cmd("mountpoint", &["-q", mnt]);
    if !check.success {
        let _ = run_privileged("rmdir", &[mnt]);
    }
}

/// RAII guard: automatically unmounts a path when dropped.
/// Prevents mount leaks if the calling code panics or returns early.
pub(super) struct AutoUmount(pub String);

impl Drop for AutoUmount {
    fn drop(&mut self) {
        safe_umount(&self.0);
    }
}

// ─── Rsync ────────────────────────────────────────────────────

pub(super) fn run_rsync(
    src: &str,
    dst: &str,
    excludes: &[String],
    delete: bool,
) -> Result<CommandResult, String> {
    let mut rsync_args: Vec<String> = vec![
        "-aAX".to_string(),
        "--info=stats1".to_string(),
        "--no-inc-recursive".to_string(),
        "--numeric-ids".to_string(),
    ];
    if delete {
        rsync_args.push("--delete".to_string());
        rsync_args.push("--delete-excluded".to_string());
    }
    for exc in excludes {
        rsync_args.push(format!("--exclude={}", exc));
    }
    rsync_args.push(src.to_string());
    rsync_args.push(dst.to_string());

    let rsync_refs: Vec<&str> = rsync_args.iter().map(|s| s.as_str()).collect();

    // When running as root, wrap rsync with ionice for idle I/O scheduling.
    // When not root, escalate only rsync via pkexec — ionice on the pkexec
    // wrapper process would not propagate to the spawned child correctly.
    let result = if is_root() {
        let mut args: Vec<String> = vec!["-c3".to_string(), "rsync".to_string()];
        args.extend(rsync_args);
        let args_ref: Vec<&str> = args.iter().map(|s| s.as_str()).collect();
        run_cmd("ionice", &args_ref)
    } else {
        run_privileged("rsync", &rsync_refs)
    };

    if !result.success && result.exit_code != 24 {
        return Err(format!(
            "rsync {} -> {}: exit={} {}",
            src, dst, result.exit_code, result.stderr
        ));
    }
    Ok(result)
}

// ─── Streaming rsync with live byte progress ──────────────────

/// Spawn rsync as a child process and stream progress2 events to the frontend.
/// Falls back gracefully if progress parsing fails.
pub(super) fn run_rsync_streaming(
    app: &tauri::AppHandle,
    src: &str,
    dst: &str,
    excludes: &[String],
    delete: bool,
    phase_name: &str,
) -> Result<CommandResult, String> {
    use tauri::Emitter;

    let mut rsync_args: Vec<String> = vec![
        "-aAX".to_string(),
        "--info=stats1,progress2".to_string(),
        "--no-inc-recursive".to_string(),
        "--numeric-ids".to_string(),
    ];
    if delete {
        rsync_args.push("--delete".to_string());
        rsync_args.push("--delete-excluded".to_string());
    }
    for exc in excludes {
        rsync_args.push(format!("--exclude={}", exc));
    }
    rsync_args.push(src.to_string());
    rsync_args.push(dst.to_string());

    let mut child = if is_root() {
        let mut args = vec!["-c3".to_string(), "rsync".to_string()];
        args.extend(rsync_args);
        let refs: Vec<&str> = args.iter().map(|s| s.as_str()).collect();
        Command::new("ionice")
            .args(&refs)
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .spawn()
            .map_err(|e| format!("ionice rsync spawn: {}", e))?
    } else {
        let mut all: Vec<String> = vec!["rsync".to_string()];
        all.extend(rsync_args);
        let refs: Vec<&str> = all.iter().map(|s| s.as_str()).collect();
        Command::new("pkexec")
            .args(&refs)
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .spawn()
            .map_err(|e| format!("pkexec rsync spawn: {}", e))?
    };

    let stdout = child.stdout.take().ok_or("rsync: no stdout")?;
    let stderr = child.stderr.take().ok_or("rsync: no stderr")?;
    let app_clone = app.clone();
    let phase = phase_name.to_string();

    // True streaming: process bytes as they arrive, emit events per progress line.
    // rsync --info=progress2 uses \r to overwrite the progress line in-place,
    // so we split on both \r and \n to capture each update individually.
    let stdout_thread = std::thread::spawn(move || {
        let mut reader = BufReader::new(stdout);
        let mut stats_output = String::new();
        let mut segment: Vec<u8> = Vec::with_capacity(256);

        loop {
            let consumed = {
                let buf = match reader.fill_buf() {
                    Ok(b) if b.is_empty() => break,
                    Ok(b) => b,
                    Err(_) => break,
                };
                let len = buf.len();
                for &byte in buf {
                    if byte == b'\r' || byte == b'\n' {
                        if !segment.is_empty() {
                            let s = String::from_utf8_lossy(&segment).trim().to_string();
                            segment.clear();
                            if !s.is_empty() {
                                if let Some((bytes, pct, speed)) = parse_rsync_progress2(&s) {
                                    let _ = app_clone.emit(
                                        "rsync-bytes-progress",
                                        serde_json::json!({
                                            "phase": phase,
                                            "bytes": bytes,
                                            "pct": pct,
                                            "speed": speed,
                                        }),
                                    );
                                } else {
                                    stats_output.push_str(&s);
                                    stats_output.push('\n');
                                }
                            }
                        }
                    } else {
                        segment.push(byte);
                    }
                }
                len
            };
            reader.consume(consumed);
        }

        // Flush any trailing segment (stats line without trailing newline)
        if !segment.is_empty() {
            let s = String::from_utf8_lossy(&segment).trim().to_string();
            if !s.is_empty() {
                stats_output.push_str(&s);
                stats_output.push('\n');
            }
        }
        stats_output
    });

    // Read stderr in a separate thread to prevent pipe deadlock
    let stderr_thread = std::thread::spawn(move || {
        let mut buf = String::new();
        BufReader::new(stderr).read_to_string(&mut buf).ok();
        buf
    });

    let status = child.wait().map_err(|e| format!("rsync wait: {}", e))?;
    let stdout_str = stdout_thread.join().unwrap_or_default();
    let stderr_str = stderr_thread.join().unwrap_or_default();
    let exit_code = status.code().unwrap_or(-1);

    if !status.success() && exit_code != 24 {
        return Err(format!(
            "rsync {} -> {}: exit={} {}",
            src, dst, exit_code, stderr_str.trim()
        ));
    }
    Ok(CommandResult {
        success: status.success() || exit_code == 24,
        stdout: stdout_str,
        stderr: stderr_str,
        exit_code,
    })
}

/// Parse an rsync --info=progress2 progress line.
/// Format: "  1,234,567  45%  12.34MB/s  0:00:17 (xfr#1, to-chk=N/T)"
fn parse_rsync_progress2(line: &str) -> Option<(u64, u8, String)> {
    let trimmed = line.trim();
    if !trimmed.contains('%') || !trimmed.contains("to-chk=") {
        return None;
    }
    let pct_idx = trimmed.find('%')?;
    let before = &trimmed[..pct_idx];
    let tokens: Vec<&str> = before.split_whitespace().collect();
    let pct: u8 = tokens.last()?.parse().ok()?;
    let bytes: u64 = tokens.first()?.replace(',', "").parse().ok()?;
    let after = trimmed[pct_idx + 1..].trim();
    let speed = after.split_whitespace().next().unwrap_or("").to_string();
    Some((bytes, pct, speed))
}

// ─── EFI Helpers ──────────────────────────────────────────────

pub(crate) fn derive_efi_partition(btrfs_dev: &str) -> String {
    let parent = Command::new("lsblk")
        .args(["-nro", "PKNAME", btrfs_dev])
        .output()
        .ok()
        .filter(|o| o.status.success())
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_default();

    if !parent.is_empty() {
        let result = Command::new("lsblk")
            .args(["-nro", "NAME,PARTTYPE", &format!("/dev/{}", parent)])
            .output();
        if let Ok(o) = result {
            if o.status.success() {
                for line in String::from_utf8_lossy(&o.stdout).lines() {
                    let parts: Vec<&str> = line.split_whitespace().collect();
                    if parts.len() >= 2 {
                        let parttype = parts[1].to_lowercase();
                        if parttype == "c12a7328-f81f-11d2-ba4b-00a0c93ec93b" {
                            return format!("/dev/{}", parts[0]);
                        }
                    }
                }
            }
        }
    }

    if let Some(pos) = btrfs_dev.rfind('p') {
        if btrfs_dev[pos + 1..].chars().all(|c| c.is_ascii_digit()) {
            return format!("{}1", &btrfs_dev[..=pos]);
        }
    }
    let base = btrfs_dev.trim_end_matches(|c: char| c.is_ascii_digit());
    format!("{}1", base)
}

pub(crate) fn detect_efi_arch() -> String {
    let uname = Command::new("uname")
        .arg("-m")
        .output()
        .ok()
        .filter(|o| o.status.success())
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_else(|| "x86_64".to_string());
    match uname.as_str() {
        "aarch64" => "arm64".to_string(),
        "i686" => "i386".to_string(),
        other => other.to_string(),
    }
}

pub(crate) fn efi_arch_suffix(arch: &str) -> &str {
    match arch {
        "aarch64" | "arm64" => "aa64",
        "i386" | "i686" => "ia32",
        _ => "x64",
    }
}

pub(crate) fn derive_parent_disk(partition: &str) -> String {
    Command::new("lsblk")
        .args(["-nro", "PKNAME", partition])
        .output()
        .ok()
        .filter(|o| o.status.success())
        .map(|o| {
            let name = String::from_utf8_lossy(&o.stdout).trim().to_string();
            if name.is_empty() { String::new() } else { format!("/dev/{}", name) }
        })
        .unwrap_or_default()
}

pub(crate) fn get_partition_uuid(dev: &str) -> String {
    run_cmd("blkid", &["-s", "UUID", "-o", "value", dev])
        .stdout
        .trim()
        .to_string()
}

// ─── Fstab & Boot Entry Patching ──────────────────────────────

pub(super) fn patch_backup_fstab(
    backup_mnt: &str,
    primary_btrfs_uuid: &str,
    backup_btrfs_uuid: &str,
    primary_efi_uuid: &str,
    backup_efi_uuid: &str,
    log_path: &str,
) -> Result<(), String> {
    for (val, label) in [
        (primary_btrfs_uuid, "primary_btrfs_uuid"),
        (backup_btrfs_uuid, "backup_btrfs_uuid"),
        (primary_efi_uuid, "primary_efi_uuid"),
        (backup_efi_uuid, "backup_efi_uuid"),
    ] {
        if !val.is_empty() && val.chars().any(|c| SHELL_DANGEROUS.contains(&c)) {
            return Err(format!("{}: enthält gefährliche Zeichen", label));
        }
    }
    validate_safe_path(backup_mnt, "backup_mnt")?;

    let fstab_path = format!("{}/etc/fstab", backup_mnt);
    let mut sed_args = Vec::new();

    if !primary_btrfs_uuid.is_empty() && !backup_btrfs_uuid.is_empty()
        && primary_btrfs_uuid != backup_btrfs_uuid
    {
        sed_args.push(format!("s/{}/___BACKSNAP_SWAP_BTRFS___/g", primary_btrfs_uuid));
        sed_args.push(format!("s/{}/{}/g", backup_btrfs_uuid, primary_btrfs_uuid));
        sed_args.push(format!("s/___BACKSNAP_SWAP_BTRFS___/{}/g", backup_btrfs_uuid));
    }

    if !primary_efi_uuid.is_empty() && !backup_efi_uuid.is_empty()
        && primary_efi_uuid != backup_efi_uuid
    {
        sed_args.push(format!("s/{}/___BACKSNAP_SWAP_EFI___/g", primary_efi_uuid));
        sed_args.push(format!("s/{}/{}/g", backup_efi_uuid, primary_efi_uuid));
        sed_args.push(format!("s/___BACKSNAP_SWAP_EFI___/{}/g", backup_efi_uuid));
    }

    if sed_args.is_empty() {
        sync_log(log_path, "fstab-Patch: Keine UUIDs zum Tauschen.");
        return Ok(());
    }

    let mut args: Vec<String> = vec!["sed".to_string(), "-i".to_string()];
    for expr in &sed_args {
        args.push("-e".to_string());
        args.push(expr.clone());
    }
    args.push(fstab_path.clone());

    let args_ref: Vec<&str> = args.iter().map(|s| s.as_str()).collect();
    let result = run_privileged(&args_ref[0], &args_ref[1..]);

    if result.success {
        sync_log(
            log_path,
            &format!(
                "fstab-Patch OK: UUIDs getauscht (Btrfs: {} ↔ {}, EFI: {} ↔ {})",
                primary_btrfs_uuid, backup_btrfs_uuid,
                primary_efi_uuid, backup_efi_uuid
            ),
        );
        Ok(())
    } else {
        let msg = format!("fstab-Patch fehlgeschlagen: {}", result.stderr.trim());
        sync_log(log_path, &msg);
        Err(msg)
    }
}

pub(super) fn patch_backup_boot_entries(
    boot_mnt: &str,
    primary_btrfs_uuid: &str,
    backup_btrfs_uuid: &str,
    bootloader_type: &str,
    backup_label: &str,
    primary_label: &str,
    log_path: &str,
) -> Result<(), String> {
    if primary_btrfs_uuid.is_empty() || backup_btrfs_uuid.is_empty()
        || primary_btrfs_uuid == backup_btrfs_uuid
    {
        return Ok(());
    }

    for (val, label) in [
        (primary_btrfs_uuid, "primary_btrfs_uuid"),
        (backup_btrfs_uuid, "backup_btrfs_uuid"),
        (boot_mnt, "boot_mnt"),
    ] {
        if val.chars().any(|c| SHELL_DANGEROUS.contains(&c)) {
            return Err(format!("{}: enthält gefährliche Zeichen", label));
        }
    }

    let patched_count;

    match bootloader_type {
        "grub" => {
            let script = format!(
                "for f in {mnt}/grub/grub.cfg {mnt}/boot/grub/grub.cfg {mnt}/grub2/grub.cfg; do \
                   if [ -f \"$f\" ]; then \
                     sed -i 's/UUID={primary}/UUID={backup}/g' \"$f\"; \
                     echo \"PATCHED:$f\"; \
                   fi; \
                 done",
                mnt = boot_mnt,
                primary = primary_btrfs_uuid,
                backup = backup_btrfs_uuid,
            );
            let result = run_privileged("sh", &["-c", &script]);
            patched_count = result.stdout.matches("PATCHED:").count();
        }
        _ => {
            let safe_backup_label = backup_label
                .chars()
                .filter(|c| c.is_alphanumeric() || *c == ' ' || *c == '-' || *c == '_')
                .collect::<String>();
            let safe_primary_label = primary_label
                .chars()
                .filter(|c| c.is_alphanumeric() || *c == ' ' || *c == '-' || *c == '_')
                .collect::<String>();

            let short_backup = if safe_backup_label.len() > 20 {
                safe_backup_label[..20].trim().to_string()
            } else {
                safe_backup_label.clone()
            };
            let short_primary = if safe_primary_label.len() > 20 {
                safe_primary_label[..20].trim().to_string()
            } else {
                safe_primary_label.clone()
            };

            let script = format!(
                "count=0; \
                 for f in {mnt}/loader/entries/*.conf; do \
                   [ -f \"$f\" ] || continue; \
                   sed -i \
                     -e 's/UUID={primary}/UUID={backup}/g' \
                     -e 's/({plabel})/({blabel})/g' \
                     \"$f\"; \
                   count=$((count+1)); \
                 done; \
                 echo \"PATCHED:$count\"",
                mnt = boot_mnt,
                primary = primary_btrfs_uuid,
                backup = backup_btrfs_uuid,
                plabel = short_primary,
                blabel = short_backup,
            );
            let result = run_privileged("sh", &["-c", &script]);
            patched_count = result
                .stdout
                .lines()
                .find_map(|l| l.strip_prefix("PATCHED:"))
                .and_then(|n| n.trim().parse::<usize>().ok())
                .unwrap_or(0);
        }
    }

    sync_log(
        log_path,
        &format!(
            "Boot-Entry-Patch OK: {} Einträge angepasst (UUID: {} → {})",
            patched_count, primary_btrfs_uuid, backup_btrfs_uuid
        ),
    );
    Ok(())
}

// ─── Sync Status ──────────────────────────────────────────────

/// Pass `boot_uuid` if already known to avoid a redundant `findmnt` subprocess call.
pub(crate) fn get_sync_status_internal(c: &AppConfig, boot_uuid: Option<&str>) -> SyncStatus {
    let timer = run_cmd("systemctl", &["is-active", &c.sync.timer_unit]);
    let timer_active = timer.stdout.trim() == "active";

    let timer_info = run_cmd(
        "systemctl",
        &[
            "show",
            &c.sync.timer_unit,
            "--property=NextElapseUSecRealtime,LastTriggerUSec",
            "--no-pager",
        ],
    );
    let mut timer_next = None;
    let mut timer_last_trigger = None;
    for line in timer_info.stdout.lines() {
        if let Some(val) = line.strip_prefix("NextElapseUSecRealtime=") {
            if !val.is_empty() {
                timer_next = Some(val.to_string());
            }
        } else if let Some(val) = line.strip_prefix("LastTriggerUSec=") {
            if !val.is_empty() {
                timer_last_trigger = Some(val.to_string());
            }
        }
    }

    let log_content = fs::read_to_string(&c.sync.log_path).unwrap_or_default();
    let all_lines: Vec<&str> = log_content.lines().collect();
    let log_lines: Vec<String> = all_lines
        .iter()
        .rev()
        .take(50)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .map(|l| l.to_string())
        .collect();

    let last_sync = log_lines
        .iter()
        .rev()
        .find(|l| l.contains("Sync fertig"))
        .cloned();

    let last_duration = last_sync.as_ref().and_then(|line| {
        line.find("(Dauer: ").map(|start| {
            let rest = &line[start + 8..];
            rest.trim_end_matches(" ===")
                .trim_end_matches(')')
                .to_string()
        })
    });

    let boot_uuid = boot_uuid
        .map(|s| s.to_string())
        .unwrap_or_else(get_boot_uuid);
    let direction = format!(
        "{} -> {}",
        disk_label(&boot_uuid, c),
        if boot_uuid == c.disks.primary_uuid {
            &c.disks.backup_label
        } else {
            &c.disks.primary_label
        }
    );

    SyncStatus {
        last_sync,
        last_duration,
        timer_active,
        timer_next,
        timer_last_trigger,
        direction,
        log_tail: log_lines,
        sync_running: SYNC_RUNNING.load(Ordering::SeqCst),
    }
}

// ─── Tauri Commands ───────────────────────────────────────────

#[tauri::command]
pub async fn run_sync(app: tauri::AppHandle) -> Result<CommandResult, String> {
    if SYNC_RUNNING
        .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
        .is_err()
    {
        return Err("Sync läuft bereits".to_string());
    }

    let result = tokio::task::spawn_blocking(move || do_sync(&app))
        .await
        .map_err(|e| format!("Spawn error: {}", e))
        .and_then(|r| r);

    SYNC_RUNNING.store(false, Ordering::SeqCst);
    invalidate_caches();
    result
}

fn do_sync(app: &tauri::AppHandle) -> Result<CommandResult, String> {
    let _lock = SyncLock::acquire()?;
    let c = cfg();
    validate_sync_config(&c)?;

    let start_time = Instant::now();
    rotate_log(&c.sync.log_path, c.sync.log_max_lines);

    emit_progress(app, "init", "Preflight-Check...", 0);

    if !cmd_exists("rsync") {
        return Err("rsync nicht installiert".to_string());
    }

    let ctx = detect_sync_direction(&c)?;
    sync_log(&c.sync.log_path, &format!("=== Sync Start: {} ===", ctx.direction));
    emit_progress(app, "init", &format!("Richtung: {}", ctx.direction), 5);

    let total_phases = c.sync.subvolumes.len() + if c.boot.sync_enabled { 1 } else { 0 };
    let pct_per_phase = if total_phases > 0 { 80.0_f32 / total_phases as f32 } else { 80.0_f32 };

    for (i, sv) in c.sync.subvolumes.iter().enumerate() {
        let phase_num = i + 1;
        let pct_start = (10.0 + (i as f32 * pct_per_phase)).min(95.0) as u8;
        let pct_end = (10.0 + ((i + 1) as f32 * pct_per_phase)).min(95.0) as u8;
        let mnt = format!("{}-{}", ctx.mount_base, sv.name);

        emit_progress(
            app,
            &sv.name,
            &format!("{} ({}) synchronisieren...", sv.name, sv.source),
            pct_start,
        );
        sync_log(
            &c.sync.log_path,
            &format!("Phase {}/{}: Sync {} ...", phase_num, total_phases, sv.source),
        );

        mount_subvol(&ctx.backup_dev, &mnt, &sv.subvol, &c.sync.mount_options).map_err(|e| {
            sync_log(&c.sync.log_path, &format!("FEHLER mount {}: {}", sv.subvol, e));
            e
        })?;
        // RAII guard: unmount automatically even if the code below panics or returns early.
        let _umount_guard = AutoUmount(mnt.clone());

        let excludes_raw: Vec<String> = if sv.source == "/" {
            c.sync.system_excludes.clone()
        } else if sv.source == super::helpers::get_home_mountpoint() || sv.source == super::helpers::get_home_mountpoint().trim_end_matches('/') {
            let mut exc = c.sync.home_excludes.clone();
            if c.sync.extra_excludes_on_primary && ctx.is_primary_boot {
                exc.extend(c.sync.home_extra_excludes.clone());
                sync_log(
                    &c.sync.log_path,
                    &format!("Phase {}/{}: {} (mit Extra-Excludes)", phase_num, total_phases, sv.source),
                );
            }
            exc
        } else {
            Vec::new()
        };

        let excludes = sanitize_excludes(&excludes_raw);
        if excludes.len() != excludes_raw.len() {
            sync_log(
                &c.sync.log_path,
                &format!(
                    "Phase {}/{}: Excludes normalisiert ({} -> {}) für {}",
                    phase_num,
                    total_phases,
                    excludes_raw.len(),
                    excludes.len(),
                    sv.source
                ),
            );
        }

        let src = if sv.source.ends_with('/') {
            sv.source.clone()
        } else {
            format!("{}/", sv.source)
        };

        match run_rsync_streaming(app, &src, &format!("{}/", mnt), &excludes, sv.delete, &sv.name) {
            Ok(r) => {
                let stats: Vec<&str> = r
                    .stdout
                    .lines()
                    .filter(|l| l.contains("bytes") || l.contains("transferred"))
                    .collect();
                sync_log(
                    &c.sync.log_path,
                    &format!("{} OK. {}", sv.name, stats.join(" | ")),
                );
            }
            Err(e) => {
                // _umount_guard drops here automatically
                sync_log(&c.sync.log_path, &format!("FEHLER {}-Sync: {}", sv.name, e));
                return Err(e);
            }
        }

        if sv.source == "/" {
            let backup_efi_dev = derive_efi_partition(&ctx.backup_dev);
            let primary_efi_dev = derive_efi_partition(
                &run_cmd("blkid", &["-U", &c.disks.primary_uuid]).stdout.trim().to_string(),
            );
            let backup_efi_uuid = get_partition_uuid(&backup_efi_dev);
            let primary_efi_uuid = get_partition_uuid(&primary_efi_dev);

            match patch_backup_fstab(
                &mnt,
                &c.disks.primary_uuid,
                &c.disks.backup_uuid,
                &primary_efi_uuid,
                &backup_efi_uuid,
                &c.sync.log_path,
            ) {
                Ok(()) => {}
                Err(e) => sync_log(&c.sync.log_path, &format!("WARNUNG fstab-Patch: {}", e)),
            }
        }

        // _umount_guard drops here at end of loop body
        emit_progress(app, &sv.name, &format!("{} fertig", sv.name), pct_end);
    }

    // ── Boot sync (optional) ──
    if c.boot.sync_enabled {
        let boot_pct = (10.0 + (c.sync.subvolumes.len() as f32 * pct_per_phase)).min(95.0) as u8;
        emit_progress(app, "boot", "Boot-Dateien synchronisieren...", boot_pct);
        sync_log(
            &c.sync.log_path,
            &format!("Phase {}/{}: Sync /boot ...", total_phases, total_phases),
        );

        let backup_efi = derive_efi_partition(&ctx.backup_dev);
        let boot_mnt = BOOT_MOUNT;
        let _ = run_privileged("mkdir", &["-p", boot_mnt]);

        let mount_res = run_privileged("mount", &[&backup_efi, boot_mnt]);
        if mount_res.success {
            // RAII guard: unmounts boot_mnt when this if-block ends, even on early return.
            let _boot_guard = AutoUmount(boot_mnt.to_string());
            let boot_excludes = sanitize_excludes(&c.boot.excludes);
            if boot_excludes.len() != c.boot.excludes.len() {
                sync_log(
                    &c.sync.log_path,
                    &format!(
                        "Boot-Excludes normalisiert ({} -> {})",
                        c.boot.excludes.len(),
                        boot_excludes.len()
                    ),
                );
            }

            match run_rsync_streaming(app, "/boot/", &format!("{}/", boot_mnt), &boot_excludes, false, "boot") {
                Ok(_) => sync_log(&c.sync.log_path, "Boot-Dateien OK."),
                Err(e) => sync_log(&c.sync.log_path, &format!("WARNUNG Boot-Sync: {}", e)),
            }

            match c.boot.bootloader_type.as_str() {
                "systemd-boot" => {
                    let bl_update = run_privileged("bootctl", &["update", &format!("--esp-path={}", boot_mnt), "--no-variables"]);
                    if bl_update.success {
                        sync_log(&c.sync.log_path, "Bootloader-Update (systemd-boot) auf Backup-EFI OK.");
                    } else {
                        sync_log(&c.sync.log_path, &format!("WARNUNG Bootloader-Update: {}", bl_update.stderr.trim()));
                    }
                }
                "grub" => {
                    let parent = derive_parent_disk(&backup_efi);
                    if !parent.is_empty() {
                        let arch = detect_efi_arch();
                        let grub_target = format!("--target={}-efi", arch);
                        let grub_install = run_privileged("grub-install", &[
                            &grub_target,
                            "--efi-directory", boot_mnt,
                            "--boot-directory", boot_mnt,
                            "--removable",
                            &parent,
                        ]);
                        if grub_install.success {
                            sync_log(&c.sync.log_path, "GRUB auf Backup-EFI installiert.");
                        } else {
                            let grub2 = run_privileged("grub2-install", &[
                                &grub_target,
                                "--efi-directory", boot_mnt,
                                "--boot-directory", boot_mnt,
                                "--removable",
                                &parent,
                            ]);
                            if grub2.success {
                                sync_log(&c.sync.log_path, "GRUB2 auf Backup-EFI installiert.");
                            } else {
                                sync_log(&c.sync.log_path, &format!("WARNUNG GRUB-Install: {}", grub_install.stderr.trim()));
                            }
                        }
                    }
                }
                _ => {
                    sync_log(&c.sync.log_path, "WARNUNG: Unbekannter Bootloader-Typ, Boot-Update übersprungen.");
                }
            }

            match patch_backup_boot_entries(
                boot_mnt,
                &c.disks.primary_uuid,
                &c.disks.backup_uuid,
                &c.boot.bootloader_type,
                &c.disks.backup_label,
                &c.disks.primary_label,
                &c.sync.log_path,
            ) {
                Ok(()) => {}
                Err(e) => sync_log(&c.sync.log_path, &format!("WARNUNG Boot-Entry-Patch: {}", e)),
            }
        } else {
            sync_log(
                &c.sync.log_path,
                &format!("WARNUNG: Konnte Backup-EFI {} nicht mounten: {}", backup_efi, mount_res.stderr),
            );
        }
        // _boot_guard drops here (no-op if mount failed)
    }

    let elapsed = start_time.elapsed().as_secs();
    let duration_str = format_duration(elapsed);
    emit_progress(
        app,
        "done",
        &format!("Sync abgeschlossen in {}", duration_str),
        100,
    );
    sync_log(
        &c.sync.log_path,
        &format!("=== Sync fertig: {} (Dauer: {}) ===", ctx.direction, duration_str),
    );

    Ok(CommandResult {
        success: true,
        stdout: format!("Sync abgeschlossen: {} (Dauer: {})", ctx.direction, duration_str),
        stderr: String::new(),
        exit_code: 0,
    })
}

#[tauri::command]
pub async fn get_sync_status() -> Result<SyncStatus, String> {
    tokio::task::spawn_blocking(|| {
        let c = cfg();
        Ok(get_sync_status_internal(&c, None))
    })
    .await
    .map_err(|e| format!("Sync-Status thread panicked: {}", e))?
}

#[tauri::command]
pub async fn get_sync_log() -> Result<Vec<String>, String> {
    tokio::task::spawn_blocking(|| {
        let c = cfg();
        let content =
            fs::read_to_string(&c.sync.log_path).unwrap_or_else(|_| "Log nicht vorhanden".to_string());
        Ok(content.lines().map(|l| l.to_string()).collect())
    })
    .await
    .map_err(|e| format!("Sync-Log thread panicked: {}", e))?
}

/// TTL for btrfs usage cache: 5 minutes.
const BTRFS_CACHE_TTL: std::time::Duration = std::time::Duration::from_secs(300);

#[tauri::command]
pub async fn get_btrfs_usage() -> Result<String, String> {
    tokio::task::spawn_blocking(|| {
        let cache = BTRFS_USAGE_CACHE.get_or_init(|| std::sync::Mutex::new(None));
        let guard = cache.lock().unwrap();
        // Return cached value if still fresh
        if let Some((ref cached, ref ts)) = *guard {
            if ts.elapsed() < BTRFS_CACHE_TTL {
                return Ok(cached.clone());
            }
        }
        // Cache miss or expired
        drop(guard);
        let result = run_privileged(
            "btrfs",
            &["filesystem", "usage", "/", "--human-readable"],
        );
        let mut guard = BTRFS_USAGE_CACHE.get().unwrap().lock().unwrap();
        if result.success {
            *guard = Some((result.stdout.clone(), std::time::Instant::now()));
            Ok(result.stdout)
        } else {
            Err(result.stderr)
        }
    })
    .await
    .map_err(|e| format!("Btrfs-Thread panicked: {}", e))?
}

#[tauri::command]
pub async fn get_system_monitor() -> Result<crate::sysmon::SystemMonitorData, String> {
    tokio::task::spawn_blocking(|| Ok(crate::sysmon::read_system_monitor()))
        .await
        .map_err(|e| format!("Monitor-Thread panicked: {}", e))?
}

// ─── Backup Verification ──────────────────────────────────────

#[tauri::command]
pub async fn verify_backup() -> Result<super::helpers::BackupVerifyResult, String> {
    tokio::task::spawn_blocking(|| verify_backup_internal())
        .await
        .map_err(|e| format!("Verify-Thread panicked: {}", e))?
}

fn verify_backup_internal() -> Result<super::helpers::BackupVerifyResult, String> {
    use super::helpers::{BackupCheck, BackupVerifyResult};

    let c = cfg();
    if c.disks.backup_uuid.is_empty() {
        return Err("Backup-Disk nicht konfiguriert".to_string());
    }

    let backup_uuid = c.disks.backup_uuid.clone();
    let primary_uuid = c.disks.primary_uuid.clone();
    let mut checks: Vec<BackupCheck> = Vec::new();
    let tmp_mnt = "/tmp/backsnap-verify";
    let efi_mnt = "/tmp/backsnap-verify-efi";

    // ── Resolve backup block device ──
    let backup_dev = {
        let r = run_cmd("blkid", &["-U", &backup_uuid]);
        if !r.success {
            return Err(format!("Backup-Disk nicht gefunden (UUID {})", backup_uuid));
        }
        r.stdout.trim().to_string()
    };

    // ── Mount backup btrfs (subvolid=5 = fs root) ──
    let _ = run_privileged("mkdir", &["-p", tmp_mnt]);
    let mount_res = run_privileged(
        "mount",
        &[
            "-o",
            "subvolid=5,ro",
            &backup_dev,
            tmp_mnt,
        ],
    );
    if !mount_res.success {
        return Err(format!("Kann Backup nicht mounten: {}", mount_res.stderr));
    }

    // ── Check 1: fstab UUID correctness ──
    let fstab_check = {
        // Find the subvol for source "/"
        let root_subvol = c.sync.subvolumes.iter().find(|sv| sv.source == "/");
        if let Some(sv) = root_subvol {
            let fstab_path = format!("{}/{}/etc/fstab", tmp_mnt, sv.subvol.trim_start_matches('/'));
            match fs::read_to_string(&fstab_path) {
                Ok(content) => {
                    let has_backup = content.contains(&backup_uuid);
                    let has_primary = content.contains(&primary_uuid);
                    if has_backup && !has_primary {
                        BackupCheck {
                            name: "fstab UUID".to_string(),
                            ok: true,
                            detail: format!("Backup-UUID {} ✓ gefunden, Primary-UUID nicht vorhanden ✓", &backup_uuid[..8]),
                        }
                    } else if !has_backup {
                        BackupCheck {
                            name: "fstab UUID".to_string(),
                            ok: false,
                            detail: "Backup-UUID fehlt in fstab — fstab wurde nicht gepatcht".to_string(),
                        }
                    } else {
                        BackupCheck {
                            name: "fstab UUID".to_string(),
                            ok: false,
                            detail: "Primary-UUID noch in fstab — Backup würde falsche Disk booten".to_string(),
                        }
                    }
                }
                Err(e) => BackupCheck {
                    name: "fstab UUID".to_string(),
                    ok: false,
                    detail: format!("fstab nicht lesbar: {}", e),
                },
            }
        } else {
            BackupCheck {
                name: "fstab UUID".to_string(),
                ok: false,
                detail: "Kein Subvolume mit source=/ in Konfiguration".to_string(),
            }
        }
    };
    checks.push(fstab_check);

    safe_umount(tmp_mnt);

    // ── Check 2: EFI bootloader entries ──
    let efi_check = {
        let backup_efi_dev = derive_efi_partition(&backup_dev);
        if backup_efi_dev.is_empty() {
            BackupCheck {
                name: "EFI Bootloader".to_string(),
                ok: false,
                detail: "Konnte EFI-Partition nicht ermitteln".to_string(),
            }
        } else {
            let _ = run_privileged("mkdir", &["-p", efi_mnt]);
            let efi_mount = run_privileged("mount", &["-o", "ro", &backup_efi_dev, efi_mnt]);
            if !efi_mount.success {
                BackupCheck {
                    name: "EFI Bootloader".to_string(),
                    ok: false,
                    detail: format!("EFI mount fehlgeschlagen: {}", efi_mount.stderr),
                }
            } else {
                let entries_dir = format!("{}/loader/entries", efi_mnt);
                let found = fs::read_dir(&entries_dir)
                    .ok()
                    .map(|rd| {
                        rd.filter_map(|e| e.ok())
                            .filter(|e| e.path().extension().map(|x| x == "conf").unwrap_or(false))
                            .any(|e| {
                                fs::read_to_string(e.path())
                                    .map(|s| s.contains(&backup_uuid))
                                    .unwrap_or(false)
                            })
                    })
                    .unwrap_or(false);
                safe_umount(efi_mnt);
                BackupCheck {
                    name: "EFI Bootloader".to_string(),
                    ok: found,
                    detail: if found {
                        "Boot-Eintrag enthält Backup-UUID ✓".to_string()
                    } else {
                        "Kein Boot-Eintrag mit Backup-UUID — Loader-Eintrag wurde nicht gepatcht".to_string()
                    },
                }
            }
        }
    };
    checks.push(efi_check);

    // ── Check 3: Backup disk was recently synced (log check) ──
    let log_check = {
        let log_content = fs::read_to_string(&c.sync.log_path).unwrap_or_default();
        let synced = log_content.contains("Sync fertig");
        BackupCheck {
            name: "Sync-Log".to_string(),
            ok: synced,
            detail: if synced {
                "Mind. ein erfolgreicher Sync im Log vorhanden ✓".to_string()
            } else {
                "Noch kein erfolgreicher Sync durchgeführt".to_string()
            },
        }
    };
    checks.push(log_check);

    let overall_ok = checks.iter().all(|c| c.ok);
    Ok(BackupVerifyResult {
        backup_dev,
        overall_ok,
        checks,
    })
}

// ─── Unit Tests ───────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── parse_rsync_progress2 ──────────────────────────────────

    #[test]
    fn progress2_parses_mid_transfer() {
        let line = "    1,234,567  45%  12.34MB/s    0:00:17 (xfr#1, to-chk=456/789)";
        let (bytes, pct, speed) = parse_rsync_progress2(line).expect("should parse");
        assert_eq!(bytes, 1_234_567);
        assert_eq!(pct, 45);
        assert_eq!(speed, "12.34MB/s");
    }

    #[test]
    fn progress2_parses_100_percent() {
        let line = "  5,368,709,120 100%  98.76MB/s    0:00:52 (xfr#892, to-chk=0/1024)";
        let (bytes, pct, _) = parse_rsync_progress2(line).expect("should parse");
        assert_eq!(pct, 100);
        assert_eq!(bytes, 5_368_709_120);
    }

    #[test]
    fn progress2_rejects_stats_line() {
        assert!(parse_rsync_progress2("Number of files: 1,234 (reg: 1,100)").is_none());
        assert!(parse_rsync_progress2("Total file size: 50,000 bytes").is_none());
        assert!(parse_rsync_progress2("").is_none());
        assert!(parse_rsync_progress2("sending incremental file list").is_none());
    }

    #[test]
    fn progress2_rejects_line_without_to_chk() {
        // Line has % but no to-chk= — should not be treated as progress
        assert!(parse_rsync_progress2("  50% done approximately").is_none());
    }

    // ── sanitize_excludes ─────────────────────────────────────

    #[test]
    fn sanitize_removes_duplicates() {
        let input = vec![
            "/foo".to_string(),
            "/bar".to_string(),
            "/foo".to_string(),
        ];
        let out = sanitize_excludes(&input);
        assert_eq!(out.len(), 2);
        assert!(out.contains(&"/foo".to_string()));
        assert!(out.contains(&"/bar".to_string()));
    }

    #[test]
    fn sanitize_strips_empty_entries() {
        let input = vec!["/foo".to_string(), "".to_string(), "  ".to_string()];
        let out = sanitize_excludes(&input);
        assert_eq!(out, vec!["/foo".to_string()]);
    }

    // ── detect_sync_direction error cases ────────────────────

    #[test]
    fn direction_rejects_empty_uuids() {
        let cfg = crate::config::AppConfig {
            disks: crate::config::DiskConfig {
                primary_uuid: String::new(),
                primary_label: String::new(),
                backup_uuid: String::new(),
                backup_label: String::new(),
            },
            sync: crate::config::SyncConfig {
                timer_unit: String::new(),
                service_unit: String::new(),
                log_path: String::new(),
                log_max_lines: 0,
                mount_options: String::new(),
                mount_base: String::new(),
                subvolumes: vec![],
                system_excludes: vec![],
                home_excludes: vec![],
                home_extra_excludes: vec![],
                extra_excludes_on_primary: false,
            },
            boot: crate::config::BootConfig {
                sync_enabled: false,
                bootloader_type: "systemd-boot".to_string(),
                excludes: vec![],
            },
            snapper: crate::config::SnapperConfig { expected_configs: vec![] },
            rollback: crate::config::RollbackConfig {
                max_broken_backups: 2,
                recovery_label: String::new(),
                root_subvol: "@".to_string(),
                root_config: "root".to_string(),
            },
        };
        let result = detect_sync_direction(&cfg);
        assert!(result.is_err());
        let msg = result.unwrap_err();
        assert!(msg.contains("konfiguriert"), "expected config error, got: {}", msg);
    }
}
