//! System integration install/uninstall: binary, .desktop, polkit, pacman hook.

use super::helpers::*;
use std::fs;

// Icon embedded at compile time from the Tauri icons directory.
const ICON_128: &[u8] = include_bytes!("../../icons/128x128.png");

#[derive(serde::Serialize, serde::Deserialize, Clone, Debug)]
pub struct IntegrationStatus {
    pub binary: bool,
    pub desktop: bool,
    pub polkit: bool,
    pub pacman_hook: bool,
    pub binary_path: String,
}

/// Check which integration components are currently installed.
#[tauri::command]
pub async fn get_integration_status() -> Result<IntegrationStatus, String> {
    tokio::task::spawn_blocking(|| {
        Ok(IntegrationStatus {
            binary:      std::path::Path::new("/usr/local/bin/backsnap").exists(),
            desktop:     std::path::Path::new("/usr/share/applications/backsnap.desktop").exists(),
            polkit:      std::path::Path::new("/etc/polkit-1/rules.d/50-backsnap.rules").exists(),
            pacman_hook: std::path::Path::new("/etc/pacman.d/hooks/00-backsnap-pre.hook").exists(),
            binary_path: "/usr/local/bin/backsnap".to_string(),
        })
    })
    .await
    .map_err(|e| format!("Status-Thread panicked: {}", e))?
}

/// Install all system integration components (requires polkit escalation).
#[tauri::command]
pub async fn install_system_integration() -> Result<String, String> {
    tokio::task::spawn_blocking(|| install_integration_sync())
        .await
        .map_err(|e| format!("Install-Thread panicked: {}", e))?
}

fn install_integration_sync() -> Result<String, String> {
    let exe = std::env::current_exe()
        .map_err(|e| format!("Binary-Pfad: {}", e))?
        .to_string_lossy()
        .to_string();

    let mut log: Vec<String> = Vec::new();

    // ── Binary ──────────────────────────────────────────────
    let r = run_privileged("cp", &[&exe, "/usr/local/bin/backsnap"]);
    if r.success {
        let _ = run_privileged("chmod", &["755", "/usr/local/bin/backsnap"]);
        log.push("✓ Binary → /usr/local/bin/backsnap".to_string());
    } else {
        return Err(format!("Binary installieren: {}", r.stderr));
    }

    // ── Icon ────────────────────────────────────────────────
    let tmp_icon = "/tmp/backsnap-install.png";
    fs::write(tmp_icon, ICON_128)
        .map_err(|e| format!("Icon schreiben: {}", e))?;
    let _ = run_privileged("mkdir", &["-p", "/usr/share/icons/hicolor/128x128/apps"]);
    let ri = run_privileged("cp", &[tmp_icon, "/usr/share/icons/hicolor/128x128/apps/backsnap.png"]);
    let _ = fs::remove_file(tmp_icon);
    if ri.success {
        let _ = run_privileged("gtk-update-icon-cache", &["/usr/share/icons/hicolor"]);
        log.push("✓ Icon → /usr/share/icons/hicolor/128x128/apps/backsnap.png".to_string());
    } else {
        log.push(format!("⚠ Icon: {}", ri.stderr));
    }

    // ── .desktop ────────────────────────────────────────────
    let desktop = "[Desktop Entry]
Name=backsnap
GenericName=Backup Manager
Comment=Btrfs System Backup mit Snapper und rsync
Exec=/usr/local/bin/backsnap
Icon=backsnap
Terminal=false
Type=Application
Categories=System;Utility;
Keywords=backup;btrfs;snapper;sync;
StartupWMClass=backsnap
";
    let tmp_desk = "/tmp/backsnap-install.desktop";
    fs::write(tmp_desk, desktop).map_err(|e| format!("Desktop temp: {}", e))?;
    let r = run_privileged("cp", &[tmp_desk, "/usr/share/applications/backsnap.desktop"]);
    let _ = fs::remove_file(tmp_desk);
    if r.success {
        let _ = run_privileged("update-desktop-database", &["/usr/share/applications"]);
        log.push("✓ .desktop → /usr/share/applications/backsnap.desktop".to_string());
    } else {
        log.push(format!("⚠ .desktop: {}", r.stderr));
    }

    // ── Polkit ──────────────────────────────────────────────
    let polkit = r#"// backsnap — wheel-Mitglieder duerfen backsnap ohne Passwort ausfuehren
polkit.addRule(function(action, subject) {
    if (action.id == "org.freedesktop.policykit.exec" &&
        action.lookup("program") == "/usr/local/bin/backsnap" &&
        subject.isInGroup("wheel")) {
        return polkit.Result.YES;
    }
});
"#;
    let tmp_pk = "/tmp/backsnap-install.rules";
    fs::write(tmp_pk, polkit).map_err(|e| format!("Polkit temp: {}", e))?;
    let _ = run_privileged("mkdir", &["-p", "/etc/polkit-1/rules.d"]);
    let r = run_privileged("cp", &[tmp_pk, "/etc/polkit-1/rules.d/50-backsnap.rules"]);
    let _ = fs::remove_file(tmp_pk);
    if r.success {
        log.push("✓ Polkit → /etc/polkit-1/rules.d/50-backsnap.rules".to_string());
    } else {
        log.push(format!("⚠ Polkit: {}", r.stderr));
    }

    // ── Pacman-Hook ─────────────────────────────────────────
    let hook = "# backsnap — automatischer Snapper-Snapshot vor jedem Pacman-Update
[Trigger]
Operation = Upgrade
Operation = Install
Operation = Remove
Type = Package
Target = *

[Action]
Description = backsnap: Erstelle Pre-Update Snapshot...
When = PreTransaction
Exec = /usr/bin/snapper -c root create --type=pre --cleanup-algorithm=number --print-number --description=\"pacman update\"
Depends On = pacman
";
    let tmp_hook = "/tmp/backsnap-install.hook";
    fs::write(tmp_hook, hook).map_err(|e| format!("Hook temp: {}", e))?;
    let _ = run_privileged("mkdir", &["-p", "/etc/pacman.d/hooks"]);
    let r = run_privileged("cp", &[tmp_hook, "/etc/pacman.d/hooks/00-backsnap-pre.hook"]);
    let _ = fs::remove_file(tmp_hook);
    if r.success {
        log.push("✓ Pacman-Hook → /etc/pacman.d/hooks/00-backsnap-pre.hook".to_string());
    } else {
        log.push(format!("⚠ Pacman-Hook: {}", r.stderr));
    }

    Ok(log.join("\n"))
}

/// Remove all system integration components.
#[tauri::command]
pub async fn uninstall_system_integration() -> Result<String, String> {
    tokio::task::spawn_blocking(|| {
        let mut log: Vec<String> = Vec::new();
        for (path, label) in [
            ("/usr/local/bin/backsnap",                               "Binary"),
            ("/usr/share/applications/backsnap.desktop",              ".desktop"),
            ("/usr/share/icons/hicolor/128x128/apps/backsnap.png",    "Icon"),
            ("/etc/polkit-1/rules.d/50-backsnap.rules",               "Polkit-Regel"),
            ("/etc/pacman.d/hooks/00-backsnap-pre.hook",              "Pacman-Hook"),
        ] {
            if std::path::Path::new(path).exists() {
                let r = run_privileged("rm", &["-f", path]);
                if r.success {
                    log.push(format!("✓ {} entfernt", label));
                } else {
                    log.push(format!("⚠ {} ({}): {}", label, path, r.stderr));
                }
            } else {
                log.push(format!("– {} nicht vorhanden", label));
            }
        }
        let _ = run_privileged("gtk-update-icon-cache", &["/usr/share/icons/hicolor"]);
        let _ = run_privileged("update-desktop-database", &["/usr/share/applications"]);
        Ok(log.join("\n"))
    })
    .await
    .map_err(|e| format!("Uninstall-Thread panicked: {}", e))?
}
