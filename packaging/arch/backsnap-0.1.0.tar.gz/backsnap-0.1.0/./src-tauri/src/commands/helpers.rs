//! Shared helpers for command modules: command execution, validation, logging, caches.

use crate::config::AppConfig;
use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::fs;
use std::io::Write;
use std::path::PathBuf;
use std::process::Command;
use std::sync::atomic::AtomicBool;
use std::sync::{Mutex, OnceLock};

// ─── Statics ──────────────────────────────────────────────────

pub static SYNC_RUNNING: AtomicBool = AtomicBool::new(false);
pub static BOOT_INFO_CACHE: OnceLock<Mutex<Option<super::boot::BootInfo>>> = OnceLock::new();
pub static BOOT_VALIDATION_CACHE: OnceLock<Mutex<Option<super::boot::BootValidation>>> = OnceLock::new();
/// Cache with TTL: stores (result, timestamp). Expires after 5 minutes.
pub static BTRFS_USAGE_CACHE: OnceLock<Mutex<Option<(String, std::time::Instant)>>> = OnceLock::new();

// ─── Centralized Paths ────────────────────────────────────────

pub const LOCK_PATH: &str = "/run/backsnap-sync.lock";
pub const LOCK_PATH_FALLBACK: &str = "/tmp/backsnap-sync.lock";
pub const ROLLBACK_TMPDIR: &str = "/tmp/backsnap-rollback";
pub const BOOT_MOUNT: &str = "/tmp/backsnap-boot";

// ─── Home Mountpoint ──────────────────────────────────────────

/// Returns the base mountpoint for user home directories (e.g. "/home/" or "/var/home/").
pub fn get_home_mountpoint() -> String {
    if let Some(home) = dirs::home_dir() {
        if home.starts_with("/var/home") {
            return "/var/home/".to_string();
        } else if home.starts_with("/Users") {
            return "/Users/".to_string();
        }
    }
    "/home/".to_string()
}

// ─── Sync Lock ────────────────────────────────────────────────

/// Cross-process file lock for sync operations.
pub struct SyncLock {
    _file: fs::File,
}

impl SyncLock {
    pub fn acquire() -> Result<Self, String> {
        use std::os::unix::io::AsRawFd;

        // Try /run first (available when running as root), fall back to /tmp
        // if the file cannot be created (e.g. insufficient permissions).
        let (_lock_path, file) = {
            let primary = LOCK_PATH;
            match fs::OpenOptions::new()
                .create(true)
                .write(true)
                .truncate(false)
                .open(primary)
            {
                Ok(f) => (primary, f),
                Err(_) => {
                    let fallback = LOCK_PATH_FALLBACK;
                    let f = fs::OpenOptions::new()
                        .create(true)
                        .write(true)
                        .truncate(false)
                        .open(fallback)
                        .map_err(|e| format!("Lockfile {} erstellen fehlgeschlagen: {}", fallback, e))?;
                    (fallback, f)
                }
            }
        };

        let fd = file.as_raw_fd();
        let ret = unsafe { libc::flock(fd, libc::LOCK_EX | libc::LOCK_NB) };
        if ret != 0 {
            let err = std::io::Error::last_os_error();
            return if err.kind() == std::io::ErrorKind::WouldBlock {
                Err(
                    "Sync läuft bereits (anderer Prozess hält Lock). \
                     Warte bis der laufende Sync beendet ist."
                        .to_string(),
                )
            } else {
                Err(format!("Lockfile flock fehlgeschlagen: {}", err))
            };
        }

        let mut f = file.try_clone().map_err(|e| e.to_string())?;
        let _ = f.write_all(format!("{}\n", std::process::id()).as_bytes());

        Ok(SyncLock { _file: file })
    }
}

// ─── Cache Invalidation ──────────────────────────────────────

pub fn invalidate_caches() {
    if let Some(c) = BOOT_INFO_CACHE.get() {
        *c.lock().unwrap() = None;
    }
    if let Some(c) = BOOT_VALIDATION_CACHE.get() {
        *c.lock().unwrap() = None;
    }
    if let Some(c) = BTRFS_USAGE_CACHE.get() {
        *c.lock().unwrap() = None; // TTL cache — force refresh on next request
    }
    crate::config::invalidate_config_cache();
}

// ─── Data Types (shared across commands) ─────────────────────

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct DiskInfo {
    pub name: String,
    pub model: String,
    pub role: String,
    pub uuid: String,
    pub size: String,
    pub mountpoint: String,
    pub fstype: String,
    pub used: String,
    pub avail: String,
    pub use_percent: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Snapshot {
    pub id: u32,
    pub snap_type: String,
    pub pre_id: Option<u32>,
    pub date: String,
    pub user: String,
    pub cleanup: String,
    pub description: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SyncStatus {
    pub last_sync: Option<String>,
    pub last_duration: Option<String>,
    pub timer_active: bool,
    pub timer_next: Option<String>,
    pub timer_last_trigger: Option<String>,
    pub direction: String,
    pub log_tail: Vec<String>,
    pub sync_running: bool,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SystemStatus {
    pub hostname: String,
    pub kernel: String,
    pub uptime: String,
    pub boot_disk: String,
    pub backup_disk: String,
    pub boot_uuid: String,
    pub disks: Vec<DiskInfo>,
    pub snapper_configs: Vec<String>,
    pub snapshot_counts: Vec<SnapshotCount>,
    pub sync_status: SyncStatus,
    pub boot_info: Option<super::boot::BootInfo>,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SnapshotCount {
    pub config: String,
    pub count: u32,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct TimerConfig {
    pub enabled: bool,
    pub calendar: String,
    pub randomized_delay: String,
    pub last_trigger: Option<String>,
    pub service_result: Option<String>,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct CommandResult {
    pub success: bool,
    pub stdout: String,
    pub stderr: String,
    pub exit_code: i32,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SubvolumeInfo {
    pub id: String,
    pub gen: String,
    pub top_level: String,
    pub path: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct BackupCheck {
    pub name: String,
    pub ok: bool,
    pub detail: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct BackupVerifyResult {
    pub backup_dev: String,
    pub overall_ok: bool,
    pub checks: Vec<BackupCheck>,
}

// ─── Command Execution ───────────────────────────────────────

pub fn run_cmd(cmd: &str, args: &[&str]) -> CommandResult {
    match Command::new(cmd)
        .args(args)
        .stdin(std::process::Stdio::null())
        .output()
    {
        Ok(output) => CommandResult {
            success: output.status.success(),
            stdout: String::from_utf8_lossy(&output.stdout).to_string(),
            stderr: String::from_utf8_lossy(&output.stderr).to_string(),
            exit_code: output.status.code().unwrap_or(-1),
        },
        Err(e) => CommandResult {
            success: false,
            stdout: String::new(),
            stderr: format!("Failed to execute {}: {}", cmd, e),
            exit_code: -1,
        },
    }
}

pub fn run_privileged(cmd: &str, args: &[&str]) -> CommandResult {
    if is_root() {
        run_cmd(cmd, args)
    } else {
        let mut full_args = vec![cmd];
        full_args.extend_from_slice(args);
        run_cmd("pkexec", &full_args)
    }
}

pub fn is_root() -> bool {
    static CACHED: OnceLock<bool> = OnceLock::new();
    *CACHED.get_or_init(|| {
        Command::new("id")
            .args(["-u"])
            .output()
            .map(|o| String::from_utf8_lossy(&o.stdout).trim() == "0")
            .unwrap_or(false)
    })
}

pub fn read_proc(path: &str) -> String {
    fs::read_to_string(path)
        .unwrap_or_default()
        .trim()
        .to_string()
}

pub fn get_boot_uuid() -> String {
    run_cmd("findmnt", &["/", "-o", "UUID", "-n"])
        .stdout
        .trim()
        .to_string()
}

pub fn cfg() -> AppConfig {
    crate::config::load_config().unwrap_or_else(|_| crate::config::auto_detect_config())
}

// ─── Validation ──────────────────────────────────────────────

pub fn validate_config(config: &str) -> Result<(), String> {
    if config.is_empty() || config.len() > 64 {
        return Err("Ungültiger Config-Name: leer oder zu lang".to_string());
    }
    if !config
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
    {
        return Err(format!(
            "Ungültiger Config-Name: '{}' — nur a-z, 0-9, -, _ erlaubt",
            config
        ));
    }
    Ok(())
}

pub fn validate_description(desc: &str) -> Result<(), String> {
    if desc.len() > 256 {
        return Err("Beschreibung zu lang (max 256 Zeichen)".to_string());
    }
    if desc.chars().any(|c| SHELL_DANGEROUS.contains(&c)) {
        return Err("Beschreibung enthält ungültige Zeichen".to_string());
    }
    Ok(())
}

pub const SHELL_DANGEROUS: &[char] = &[
    '`', '$', '\\', '|', ';', '&', '<', '>', '\'', '"', '\n', '\r', '\0', '(', ')',
];

pub fn validate_safe_path(value: &str, label: &str) -> Result<(), String> {
    if value.is_empty() {
        return Err(format!("{}: darf nicht leer sein", label));
    }
    if value.chars().any(|c| SHELL_DANGEROUS.contains(&c)) {
        return Err(format!(
            "{}: enthält ungültige Zeichen (Shell-Injection verhindert): '{}'",
            label, value
        ));
    }
    Ok(())
}

pub fn validate_device_path(dev: &str) -> bool {
    !dev.is_empty()
        && dev.starts_with("/dev/")
        && dev.len() < 128
        && !dev.chars().any(|c| SHELL_DANGEROUS.contains(&c))
}

pub fn validate_sync_config(c: &AppConfig) -> Result<(), String> {
    validate_safe_path(&c.sync.mount_base, "mount_base")?;
    validate_safe_path(&c.sync.mount_options, "mount_options")?;
    for sv in &c.sync.subvolumes {
        validate_safe_path(&sv.subvol, &format!("subvol '{}'", sv.name))?;
        validate_safe_path(&sv.source, &format!("source '{}'", sv.name))?;
        validate_safe_path(&sv.name, &format!("name '{}'", sv.name))?;
    }
    for (uuid, label) in [
        (&c.disks.primary_uuid, "primary_uuid"),
        (&c.disks.backup_uuid, "backup_uuid"),
    ] {
        if !uuid.is_empty() && !uuid.chars().all(|c| c.is_ascii_hexdigit() || c == '-') {
            return Err(format!("{}: ungültiges UUID-Format '{}'", label, uuid));
        }
    }
    if !c.disks.primary_uuid.is_empty()
        && !c.disks.backup_uuid.is_empty()
        && c.disks.primary_uuid == c.disks.backup_uuid
    {
        return Err(
            "Primary und Backup UUID sind identisch! \
             Bitte unter Einstellungen zwei verschiedene Disks wählen."
                .to_string(),
        );
    }

    validate_exclude_list(&c.sync.system_excludes, "system_excludes")?;
    validate_exclude_list(&c.sync.home_excludes, "home_excludes")?;
    validate_exclude_list(&c.sync.home_extra_excludes, "home_extra_excludes")?;
    validate_exclude_list(&c.boot.excludes, "boot.excludes")?;

    Ok(())
}

fn validate_exclude_list(excludes: &[String], label: &str) -> Result<(), String> {
    if excludes.len() > 10_000 {
        return Err(format!(
            "{}: zu viele Einträge ({}) — max 10000",
            label,
            excludes.len()
        ));
    }

    for (idx, raw) in excludes.iter().enumerate() {
        let rule = raw.trim();
        if rule.is_empty() || rule.starts_with('#') {
            continue;
        }
        if rule.len() > 512 {
            return Err(format!(
                "{}[{}]: zu lang ({} Zeichen, max 512)",
                label,
                idx,
                rule.len()
            ));
        }
        if rule.chars().any(|c| SHELL_DANGEROUS.contains(&c)) {
            return Err(format!(
                "{}[{}]: enthält ungültige Zeichen: '{}'",
                label, idx, rule
            ));
        }
    }

    Ok(())
}

/// Normalize excludes before passing them to rsync.
///
/// Rules:
/// - trim whitespace
/// - ignore empty entries and comment entries (`# ...`)
/// - preserve order
/// - deduplicate exact duplicates
pub fn sanitize_excludes(excludes: &[String]) -> Vec<String> {
    let mut seen: HashSet<String> = HashSet::new();
    let mut out: Vec<String> = Vec::new();

    for raw in excludes {
        let cleaned = raw.trim();
        if cleaned.is_empty() || cleaned.starts_with('#') {
            continue;
        }

        let candidate = cleaned.to_string();
        if seen.insert(candidate.clone()) {
            out.push(candidate);
        }
    }

    out
}

// ─── Logging ─────────────────────────────────────────────────

pub fn activity_log_path() -> PathBuf {
    dirs::data_local_dir()
        .or_else(|| dirs::home_dir().map(|h| h.join(".local/share")))
        .unwrap_or_else(|| PathBuf::from("/tmp"))
        .join("backsnap")
        .join("activity.log")
}

pub fn read_activity_log_lines(max_lines: usize) -> Vec<String> {
    let path = activity_log_path();
    let content = fs::read_to_string(path).unwrap_or_default();
    let mut lines: Vec<String> = content.lines().map(|l| l.to_string()).collect();
    if lines.len() > max_lines {
        lines = lines.split_off(lines.len() - max_lines);
    }
    lines
}

fn activity_log_line(source: &str, msg: &str) -> String {
    let timestamp = chrono::Local::now().format("%F %T").to_string();
    format!("[{}] [{}] {}", timestamp, source, msg)
}

pub fn log_activity(source: &str, msg: &str) {
    let path = activity_log_path();
    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }

    let line = activity_log_line(source, msg);
    let _ = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(path)
        .and_then(|mut f| f.write_all(format!("{}\n", line).as_bytes()));
}

pub fn log_activity_with_app(app: &tauri::AppHandle, source: &str, msg: &str) {
    use tauri::Emitter;

    log_activity(source, msg);
    let line = activity_log_line(source, msg);
    let _ = app.emit("activity-log-line", line);
}

pub fn sync_log(log_path: &str, msg: &str) {
    let timestamp = chrono::Local::now().format("%F %T").to_string();
    let line = format!("[{}] {}\n", timestamp, msg);
    let _ = fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(log_path)
        .and_then(|mut f| f.write_all(line.as_bytes()));
    log_activity("sync", msg);
}

pub fn rotate_log(log_path: &str, max_lines: usize) {
    let content = match fs::read_to_string(log_path) {
        Ok(c) => c,
        Err(_) => return,
    };
    let lines: Vec<&str> = content.lines().collect();
    if lines.len() > max_lines {
        let keep = &lines[lines.len() - max_lines..];
        let new_content = keep.join("\n") + "\n";
        let _ = fs::write(log_path, new_content);
    }
}

pub fn emit_progress(app: &tauri::AppHandle, step: &str, detail: &str, pct: u8) {
    use tauri::Emitter;
    let _ = app.emit(
        "sync-progress",
        serde_json::json!({
            "step": step,
            "detail": detail,
            "percent": pct,
        }),
    );
}

pub fn format_duration(secs: u64) -> String {
    if secs >= 3600 {
        format!("{}h {}m {}s", secs / 3600, (secs % 3600) / 60, secs % 60)
    } else if secs >= 60 {
        format!("{}m {}s", secs / 60, secs % 60)
    } else {
        format!("{}s", secs)
    }
}

pub fn cmd_exists(cmd: &str) -> bool {
    run_cmd("which", &[cmd]).success
}

pub fn disk_label(uuid: &str, c: &AppConfig) -> String {
    if uuid == c.disks.primary_uuid {
        c.disks.primary_label.clone()
    } else if uuid == c.disks.backup_uuid {
        c.disks.backup_label.clone()
    } else {
        format!("Unknown ({})", uuid)
    }
}

// ─── Disk Info ───────────────────────────────────────────────

pub fn get_disk_info() -> Vec<DiskInfo> {
    let c = cfg();

    // 1. Get df info for used/avail/pcent (only relevant fstypes to skip tmpfs/NFS/efivarfs etc.)
    let df = run_cmd(
        "df",
        &[
            "-B1", // bytes
            "--output=source,used,avail,pcent",
            "-t", "btrfs",
            "-t", "vfat",
            "-t", "ext4",
            "-t", "xfs",
        ],
    );
    
    let mut df_map: std::collections::HashMap<String, (String, String, String)> = std::collections::HashMap::new();
    for line in df.stdout.lines().skip(1) {
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() >= 4 {
            let source = parts[0].trim_start_matches("/dev/").to_string();
            df_map.insert(source, (parts[1].to_string(), parts[2].to_string(), parts[3].to_string()));
        }
    }

    // 2. Get lsblk info
    let lsblk = run_cmd("lsblk", &["-b", "-J", "-o", "NAME,MODEL,PKNAME,UUID,MOUNTPOINTS,FSTYPE,SIZE"]);
    let mut disks: Vec<DiskInfo> = Vec::new();
    
    if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(&lsblk.stdout) {
        if let Some(devices) = parsed.get("blockdevices").and_then(|v| v.as_array()) {
            for dev in devices {
                let model = dev.get("model").and_then(|v| v.as_str()).unwrap_or("Unbekanntes Laufwerk").trim().to_string();
                
                if let Some(children) = dev.get("children").and_then(|v| v.as_array()) {
                    for child in children {
                        let name = child.get("name").and_then(|v| v.as_str()).unwrap_or("").trim().to_string();
                        let fstype = child.get("fstype").and_then(|v| v.as_str()).unwrap_or("").trim().to_string();
                        let uuid = child.get("uuid").and_then(|v| v.as_str()).unwrap_or("").trim().to_string();
                        
                        let mut mountpoint = "Nicht gemountet".to_string();
                        if let Some(mps) = child.get("mountpoints").and_then(|v| v.as_array()) {
                            let mut shortest = String::new();
                            for mp in mps {
                                if let Some(mp_str) = mp.as_str() {
                                    if shortest.is_empty() || mp_str.len() < shortest.len() {
                                        shortest = mp_str.to_string();
                                    }
                                }
                            }
                            if !shortest.is_empty() {
                                mountpoint = shortest;
                            }
                        }

                        let size_bytes = child.get("size").and_then(|v| v.as_u64()).unwrap_or(0);
                        
                        if fstype == "btrfs" || fstype == "vfat" || fstype == "ext4" {
                            let (used_bytes, avail_bytes, use_percent) = df_map.get(&name).cloned().unwrap_or(("0".to_string(), "0".to_string(), "0%".to_string()));
                            
                            // Format bytes to human readable
                            let format_bytes = |b: &str| -> String {
                                if let Ok(bytes) = b.parse::<f64>() {
                                    if bytes >= 1_099_511_627_776.0 {
                                        format!("{:.1}T", bytes / 1_099_511_627_776.0)
                                    } else if bytes >= 1_073_741_824.0 {
                                        format!("{:.1}G", bytes / 1_073_741_824.0)
                                    } else if bytes >= 1_048_576.0 {
                                        format!("{:.1}M", bytes / 1_048_576.0)
                                    } else {
                                        format!("{}B", bytes)
                                    }
                                } else {
                                    "0B".to_string()
                                }
                            };

                            let size = format_bytes(&size_bytes.to_string());
                            let used = if used_bytes == "0" { "0B".to_string() } else { format_bytes(&used_bytes) };
                            let avail = if avail_bytes == "0" { "0B".to_string() } else { format_bytes(&avail_bytes) };

                            let role = if uuid == c.disks.primary_uuid && !uuid.is_empty() {
                                "System Disk".to_string()
                            } else if uuid == c.disks.backup_uuid && !uuid.is_empty() {
                                "Backup Disk".to_string()
                            } else if mountpoint == "/boot" || mountpoint == "/boot/efi" {
                                "Boot Partition".to_string()
                            } else {
                                "Datenlaufwerk".to_string()
                            };

                            disks.push(DiskInfo {
                                name: format!("/dev/{}", name),
                                model: model.clone(),
                                role,
                                fstype,
                                size,
                                used,
                                avail,
                                use_percent,
                                mountpoint,
                                uuid,
                            });
                        }
                    }
                }
            }
        }
    }
    
    disks
}

pub fn get_snapper_configs() -> Vec<String> {
    let result = run_cmd("snapper", &["list-configs", "--columns", "config"]);
    result
        .stdout
        .lines()
        .skip(2)
        .map(|l| l.trim().to_string())
        .filter(|l| !l.is_empty())
        .collect()
}

pub fn get_snapshot_count(config: &str) -> u32 {
    let result = run_cmd("snapper", &["-c", config, "list", "--columns", "number"]);
    result
        .stdout
        .lines()
        // No header skip: parse filter already rejects non-numeric lines (headers,
        // warnings, empty lines) and the snapshot-0 pre-snapshot baseline.
        .filter(|l| {
            let t = l.trim();
            !t.is_empty() && t != "0" && t.parse::<u32>().is_ok()
        })
        .count() as u32
}
