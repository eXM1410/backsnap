//! Btrfs rollback commands: snapshot-based root subvolume rollback with crash-safety.

use super::helpers::*;
use std::fs;
use std::path::Path;

#[tauri::command]
pub async fn rollback_snapshot(
    app: tauri::AppHandle,
    config: String,
    id: u32,
) -> Result<CommandResult, String> {
    validate_config(&config)?;
    let c = cfg();
    let root_config = &c.rollback.root_config;
    if config != *root_config {
        return Err(format!("Rollback nur für {}-Config unterstützt", root_config));
    }

    tokio::task::spawn_blocking(move || do_rollback(&app, id))
        .await
        .map_err(|e| format!("Spawn error: {}", e))?
}

fn do_rollback(app: &tauri::AppHandle, snap_id: u32) -> Result<CommandResult, String> {
    let _lock = SyncLock::acquire().map_err(|_| 
        "Rollback nicht möglich: Es läuft bereits ein Sync oder Rollback. \
         Bitte warten bis der laufende Vorgang beendet ist.".to_string())?;
    let c = cfg();
    let boot_uuid = get_boot_uuid();

    emit_progress(
        app,
        "prepare",
        &format!("Rollback auf Snapshot #{} vorbereiten...", snap_id),
        10,
    );

    let tmpdir = ROLLBACK_TMPDIR;
    let _ = fs::create_dir_all(tmpdir);

    let dev_arg = format!("UUID={}", boot_uuid);
    let mount_opts = format!("subvolid=5,{}", c.sync.mount_options);
    let mount_res = run_privileged("mount", &["-o", &mount_opts, &dev_arg, tmpdir]);
    if !mount_res.success {
        return Err(format!(
            "Konnte Btrfs-Root nicht mounten: {}",
            mount_res.stderr
        ));
    }
    // RAII guard: unmount automatically even if do_rollback_inner panics.
    let _umount_guard = super::sync_cmd::AutoUmount(tmpdir.to_string());

    let result = do_rollback_inner(app, snap_id, tmpdir, &c);

    // _umount_guard drops here, performing the unmount + rmdir
    drop(_umount_guard);
    let _ = fs::remove_dir(tmpdir);

    result
}

fn do_rollback_inner(
    app: &tauri::AppHandle,
    snap_id: u32,
    tmpdir: &str,
    c: &crate::config::AppConfig,
) -> Result<CommandResult, String> {
    let root_subvol = &c.rollback.root_subvol;
    let possible_paths = [
        format!("{}/@.snapshots/{}/snapshot", tmpdir, snap_id),
        format!("{}/@/.snapshots/{}/snapshot", tmpdir, snap_id),
        format!("{}/.snapshots/{}/snapshot", tmpdir, snap_id),
    ];
    let snap_path = possible_paths.into_iter().find(|p| Path::new(p).exists())
        .ok_or_else(|| format!("Snapshot #{} nicht gefunden (geprüfte Pfade: @.snapshots, @/.snapshots, .snapshots)", snap_id))?;

    let diff = run_cmd(
        "snapper",
        &["-c", &c.rollback.root_config, "status", &format!("{}..0", snap_id)],
    );
    let diff_count = diff.stdout.lines().count();
    emit_progress(
        app,
        "info",
        &format!("{} geänderte Dateien seit Snapshot #{}", diff_count, snap_id),
        25,
    );

    let timestamp = chrono::Local::now().format("%Y%m%d-%H%M%S").to_string();
    let broken_name = format!("{}.broken-{}", root_subvol, timestamp);
    let current_at = format!("{}/{}", tmpdir, root_subvol);
    let broken_path = format!("{}/{}", tmpdir, broken_name);

    if !Path::new(&current_at).exists() {
        return Err(format!(
            "Kein aktives {} Subvolume gefunden",
            root_subvol
        ));
    }

    // Cleanup old broken backups (keep last N)
    emit_progress(app, "cleanup", "Alte Backups aufräumen...", 30);
    if let Ok(entries) = fs::read_dir(tmpdir) {
        let mut broken_dirs: Vec<String> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.file_name().to_string_lossy().to_string())
            .filter(|n| n.starts_with(&format!("{}.broken-", root_subvol)))
            .map(|n| format!("{}/{}", tmpdir, n))
            .collect();
        broken_dirs.sort();
        while broken_dirs.len() > c.rollback.max_broken_backups {
            let old = broken_dirs.remove(0);
            sync_log(&c.sync.log_path, &format!("Cleanup: lösche altes Backup {}", old));
            let _ = run_privileged("btrfs", &["subvolume", "delete", &old]);
        }
    }

    // ── Crash-safe rollback: snapshot first, then atomic swap ──

    let new_root_tmp = format!("{}/{}.rollback-{}", tmpdir, root_subvol, timestamp);
    emit_progress(
        app,
        "snapshot",
        &format!("Snapshot #{} erstellen...", snap_id),
        50,
    );
    let snap_res = run_privileged(
        "btrfs",
        &["subvolume", "snapshot", &snap_path, &new_root_tmp],
    );
    if !snap_res.success {
        return Err(format!(
            "Konnte Snapshot nicht erstellen: {}",
            snap_res.stderr
        ));
    }

    // Move current root → broken
    emit_progress(
        app,
        "backup",
        &format!("Aktuelles {} sichern als {} ...", root_subvol, broken_name),
        65,
    );
    sync_log(
        &c.sync.log_path,
        &format!("Rollback #{}: mv {} -> {}", snap_id, root_subvol, broken_name),
    );

    let mv_res = run_privileged("mv", &[&current_at, &broken_path]);
    if !mv_res.success {
        let _ = run_privileged("btrfs", &["subvolume", "delete", &new_root_tmp]);
        return Err(format!(
            "Konnte {} nicht verschieben: {}",
            root_subvol, mv_res.stderr
        ));
    }

    // Move new snapshot → root name
    emit_progress(
        app,
        "activate",
        &format!("Neues {} aktivieren...", root_subvol),
        80,
    );
    let mv_new = run_privileged("mv", &[&new_root_tmp, &current_at]);
    if !mv_new.success {
        sync_log(&c.sync.log_path, "KRITISCH: Rename fehlgeschlagen, stelle altes Root wieder her");
        let restore = run_privileged("mv", &[&broken_path, &current_at]);
        if restore.success {
            let del = run_privileged("btrfs", &["subvolume", "delete", &new_root_tmp]);
            if !del.success {
                sync_log(&c.sync.log_path, &format!(
                    "WARNUNG: Temp-Snapshot {} konnte nicht gelöscht werden: {}", new_root_tmp, del.stderr
                ));
            }
            return Err(format!(
                "Konnte neues Root nicht aktivieren: {}. Altes Root wiederhergestellt.",
                mv_new.stderr
            ));
        } else {
            let msg = format!(
                "FATAL: System ist möglicherweise nicht bootfähig! \
                 Weder neues Root noch altes Root ({}) konnte nach {} verschoben werden. \
                 Bitte von Live-USB booten und manuell reparieren. \
                 Temp-Snapshot: {}, Broken-Backup: {}",
                broken_path, current_at, new_root_tmp, broken_path
            );
            sync_log(&c.sync.log_path, &format!("KRITISCH: {}", msg));
            return Err(msg);
        }
    }

    let snapshots_dir = format!("{}/.snapshots", current_at);
    let _ = run_privileged("mkdir", &["-p", &snapshots_dir]);

    sync_log(
        &c.sync.log_path,
        &format!("Rollback #{} erfolgreich. Backup: {}", snap_id, broken_name),
    );

    emit_progress(
        app,
        "done",
        &format!(
            "Rollback erfolgreich! Backup: {}. Bitte neustarten.",
            broken_name
        ),
        100,
    );

    let boot_uuid = get_boot_uuid();
    let recovery_info = format!(
        "Falls etwas schiefgeht:\n\
         1. Im Boot-Menü '{}' wählen\n\
         2. mount -o subvolid=5 UUID={} /mnt\n\
         3. mv /mnt/{} /mnt/{}.bad\n\
         4. mv /mnt/{} /mnt/{}\n\
         5. reboot",
        c.rollback.recovery_label,
        boot_uuid,
        root_subvol, root_subvol,
        broken_name, root_subvol
    );

    Ok(CommandResult {
        success: true,
        stdout: format!(
            "Rollback auf Snapshot #{} erfolgreich!\n\
             Backup: {}\n\
             Geänderte Dateien: {}\n\n\
             {}\n\n\
             Bitte jetzt neustarten.",
            snap_id, broken_name, diff_count, recovery_info
        ),
        stderr: String::new(),
        exit_code: 0,
    })
}
