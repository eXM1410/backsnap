//! Cleanup commands: scan for deletable files and remove them.

use super::helpers::*;
use rayon::prelude::*;
use std::path::PathBuf;
use tauri::Emitter;

/// Represents a deletable item shown in the UI.
#[derive(serde::Serialize, serde::Deserialize, Clone, Debug)]
pub struct CleanupItem {
    pub path: String,
    pub abs_path: String,
    pub category: String,
    pub reason: String,
    pub size_bytes: u64,
    pub size_human: String,
    pub safe: bool,
}

/// Result of a deletion operation.
#[derive(serde::Serialize, Clone, Debug)]
pub struct DeleteResult {
    pub path: String,
    pub success: bool,
    pub error: Option<String>,
}

#[tauri::command]
pub fn cancel_scan() {
    crate::scanner::CANCEL_SCAN.store(true, std::sync::atomic::Ordering::SeqCst);
}

/// Scan home directory for deletable junk files (caches, build artifacts, etc.)
/// Streams results via events for live UI updates, then returns the full list.
#[tauri::command]
pub async fn scan_cleanup(app: tauri::AppHandle) -> Result<Vec<CleanupItem>, String> {
    crate::scanner::CANCEL_SCAN.store(false, std::sync::atomic::Ordering::SeqCst);
    let username = std::env::var("USER").unwrap_or_else(|_| "user".to_string());
    let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from(format!("/home/{}", username)));

    log_activity_with_app(&app, "cleanup", "Cleanup-Scan gestartet — suche löschbare Dateien...");

    let app_clone = app.clone();
    let items = tokio::task::spawn_blocking(move || {
        let results = std::sync::Mutex::new(Vec::<CleanupItem>::new());
        let batch = std::sync::Mutex::new(Vec::<CleanupItem>::new());
        let start_time = std::time::Instant::now();
        let phase_start = std::sync::Arc::new(std::sync::Mutex::new(std::time::Instant::now()));

        crate::scanner::scan_home_excludes_streaming(
            &username,
            |exclude| {
                let safe = is_safe_to_delete(&exclude.category, &exclude.path, &home);
                let abs_path = home.join(&exclude.path).to_string_lossy().to_string();
                let item = CleanupItem {
                    path: exclude.path.clone(),
                    abs_path,
                    category: format!("{:?}", exclude.category),
                    reason: exclude.reason.clone(),
                    size_bytes: exclude.size_bytes,
                    size_human: exclude.size_human.clone(),
                    safe,
                };
                
                if let Ok(mut b) = batch.lock() {
                    b.push(item.clone());
                    if b.len() >= 10 {
                        let _ = app_clone.emit("cleanup-item-batch", &*b);
                        b.clear();
                    }
                }

                if let Ok(mut r) = results.lock() {
                    r.push(item);
                }
            },
            |phase| {
                if let Ok(mut b) = batch.lock() {
                    if !b.is_empty() {
                        let _ = app_clone.emit("cleanup-item-batch", &*b);
                        b.clear();
                    }
                }
                if let Ok(mut ps) = phase_start.lock() {
                    let elapsed = ps.elapsed();
                    if phase.phase > 1 {
                        log_activity_with_app(
                            &app_clone,
                            "cleanup",
                            &format!("Phase {} abgeschlossen in {:.2?}", phase.phase - 1, elapsed),
                        );
                    }
                    *ps = std::time::Instant::now();
                }
                log_activity_with_app(
                    &app_clone,
                    "cleanup",
                    &format!("Starte Phase {}: {}", phase.phase, phase.label),
                );
                let _ = app_clone.emit("cleanup-phase", &phase);
            },
            {
                let last_emit = std::sync::Arc::new(std::sync::Mutex::new(std::time::Instant::now()));
                let app_clone_prog = app_clone.clone();
                move |path: &std::path::Path| {
                    if let Ok(mut last) = last_emit.try_lock() {
                        if last.elapsed().as_millis() > 50 {
                            let _ = app_clone_prog.emit("cleanup-progress", path.to_string_lossy().to_string());
                            *last = std::time::Instant::now();
                        }
                    }
                }
            }
        );

        if let Ok(mut b) = batch.lock() {
            if !b.is_empty() {
                let _ = app_clone.emit("cleanup-item-batch", &*b);
                b.clear();
            }
        }

        if let Ok(ps) = phase_start.lock() {
            log_activity_with_app(
                &app_clone,
                "cleanup",
                &format!("Letzte Phase abgeschlossen in {:.2?}", ps.elapsed()),
            );
        }

        log_activity_with_app(
            &app_clone,
            "cleanup",
            &format!("Gesamter Scan abgeschlossen in {:.2?}", start_time.elapsed()),
        );

        // Sort by size (largest first)
        let mut results = results.into_inner().unwrap_or_default();
        results.sort_by(|a, b| b.size_bytes.cmp(&a.size_bytes));
        results
    })
    .await
    .map_err(|e| format!("Cleanup scan thread panicked: {}", e))?;

    let total_size: u64 = items.iter().map(|i| i.size_bytes).sum();
    log_activity_with_app(
        &app,
        "cleanup",
        &format!(
            "Cleanup-Scan fertig — {} Einträge, {} gesamt",
            items.len(),
            crate::util::format_size(total_size)
        ),
    );
    let _ = app.emit("cleanup-scan-done", ());

    Ok(items)
}

/// Delete selected paths. Returns per-path success/failure.
/// Runs deletions in a blocking task to avoid freezing the UI.
#[tauri::command]
pub async fn delete_cleanup_paths(
    app: tauri::AppHandle,
    paths: Vec<String>,
) -> Result<Vec<DeleteResult>, String> {
    if paths.is_empty() {
        return Err("Keine Pfade zum Löschen ausgewählt".to_string());
    }

    let username = std::env::var("USER").unwrap_or_else(|_| "user".to_string());
    let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from(format!("/home/{}", username)));

    log_activity_with_app(
        &app,
        "cleanup",
        &format!("Lösche {} Einträge...", paths.len()),
    );

    let home_canon = std::fs::canonicalize(&home)
        .map_err(|e| format!("Home-Verzeichnis nicht auflösbar: {}", e))?;

    let app_for_task = app.clone();
    let results = tokio::task::spawn_blocking(move || {
        paths
            .into_par_iter()
            .map(|rel_path| {
                let abs = home_canon.join(&rel_path);

                // Canonicalize to resolve ".." and symlinks before checking
                let canon = match std::fs::canonicalize(&abs) {
                    Ok(p) => p,
                    Err(_) => {
                        // Path doesn't exist anymore — that's OK
                        return DeleteResult {
                            path: rel_path,
                            success: true,
                            error: None,
                        };
                    }
                };

                // Safety: only delete inside home directory
                if !canon.starts_with(&home_canon) {
                    return DeleteResult {
                        path: rel_path,
                        success: false,
                        error: Some("Pfad liegt außerhalb des Home-Verzeichnisses".to_string()),
                    };
                }

                // Don't delete the home dir itself or critical dotfiles/dirs
                // .ssh/.gnupg: entire tree protected (secrets)
                // .config/.local: only the dir itself, subdirs are fair game
                let tree_protected = [".ssh", ".gnupg"];
                let dir_protected = [".config", ".local", ".bashrc", ".profile", ".bash_history"];
                if canon == home_canon
                    || rel_path == "."
                    || rel_path == ".."
                    || tree_protected.iter().any(|p| rel_path == *p || rel_path.starts_with(&format!("{}/", p)))
                    || dir_protected.iter().any(|p| rel_path == *p)
                {
                    return DeleteResult {
                        path: rel_path,
                        success: false,
                        error: Some("Geschützter Pfad — darf nicht gelöscht werden".to_string()),
                    };
                }

                let result = if canon.is_dir() {
                    std::fs::remove_dir_all(&canon)
                } else if canon.is_file() {
                    std::fs::remove_file(&canon)
                } else {
                    return DeleteResult {
                        path: rel_path,
                        success: true,
                        error: None,
                    };
                };

                match result {
                    Ok(_) => {
                        log_activity_with_app(
                            &app_for_task,
                            "cleanup",
                            &format!("Gelöscht: {}", rel_path),
                        );
                        DeleteResult {
                            path: rel_path,
                            success: true,
                            error: None,
                        }
                    }
                    Err(e) => {
                        let err_msg = format!("{}", e);
                        log_activity_with_app(
                            &app_for_task,
                            "cleanup",
                            &format!("Fehler beim Löschen von {}: {}", rel_path, err_msg),
                        );
                        DeleteResult {
                            path: rel_path,
                            success: false,
                            error: Some(err_msg),
                        }
                    }
                }
            })
            .collect::<Vec<_>>()
    })
    .await
    .map_err(|e| format!("Delete thread panicked: {}", e))?;

    let ok_count = results.iter().filter(|r| r.success).count();
    let fail_count = results.iter().filter(|r| !r.success).count();
    log_activity_with_app(
        &app,
        "cleanup",
        &format!(
            "Löschvorgang abgeschlossen — {} gelöscht, {} fehlgeschlagen",
            ok_count, fail_count
        ),
    );

    Ok(results)
}

/// Determine if a category is safe to auto-select for deletion.
fn is_safe_to_delete(category: &crate::scanner::types::ExcludeCategory, path: &str, home: &std::path::Path) -> bool {
    use crate::scanner::types::ExcludeCategory;
    match category {
        ExcludeCategory::Cache | ExcludeCategory::Browser => true,
        ExcludeCategory::BuildArtifact => {
            // Only mark clearly identifiable build artifacts as safe.
            // /build and /dist are NOT auto-safe — too many false positives.
            let p = path.to_lowercase();
            p.ends_with("/node_modules")
                || p.contains("/node_modules/")
                || (p.ends_with("/target") && has_project_marker(path, "Cargo.toml", home))
                || p.contains("/__pycache__")
                || p.ends_with("/__pycache__")
                || p.ends_with("/.gradle")
                || p.ends_with("/.next")
                || p.ends_with("/.nuxt")
                || p.ends_with("/.angular")
                || p.ends_with("/.parcel-cache")
                || p.ends_with("/.turbo")
        }
        ExcludeCategory::Toolchain
        | ExcludeCategory::Runtime
        | ExcludeCategory::Gaming
        | ExcludeCategory::Container
        | ExcludeCategory::VirtualMachine
        | ExcludeCategory::Media
        | ExcludeCategory::Communication
        | ExcludeCategory::LargeUnknown => false,
    }
}

/// Check if the parent of a build directory contains a marker file.
/// `rel_path` is relative to home, so we prepend `home` for fs access.
fn has_project_marker(rel_path: &str, marker: &str, home: &std::path::Path) -> bool {
    let abs = home.join(rel_path);
    if let Some(parent) = abs.parent() {
        parent.join(marker).exists()
    } else {
        false
    }
}

#[derive(serde::Serialize, Clone, Debug)]
pub struct DirEntry {
    pub name: String,
    pub path: String, // relative to home
    pub is_dir: bool,
    pub size_bytes: u64,
}

#[tauri::command]
pub async fn get_cleanup_dir_contents(
    _app: tauri::AppHandle,
    rel_path: String,
) -> Result<Vec<DirEntry>, String> {
    let username = std::env::var("USER").unwrap_or_else(|_| "user".to_string());
    let home = dirs::home_dir().unwrap_or_else(|| PathBuf::from(format!("/home/{}", username)));
    let home_canon = std::fs::canonicalize(&home)
        .map_err(|e| format!("Home-Verzeichnis nicht auflösbar: {}", e))?;

    let abs = home_canon.join(&rel_path);
    let canon = std::fs::canonicalize(&abs)
        .map_err(|e| format!("Pfad nicht auflösbar: {}", e))?;

    if !canon.starts_with(&home_canon) {
        return Err("Pfad liegt außerhalb des Home-Verzeichnisses".to_string());
    }

    let mut entries = Vec::new();
    if let Ok(read_dir) = std::fs::read_dir(&canon) {
        for entry in read_dir.flatten() {
            let meta = entry.metadata().ok();
            let is_dir = meta.as_ref().map(|m| m.is_dir()).unwrap_or(false);
            let size_bytes = meta.as_ref().map(|m| m.len()).unwrap_or(0);
            let name = entry.file_name().to_string_lossy().to_string();
            
            // Construct the new relative path
            let child_rel = if rel_path.is_empty() || rel_path == "." {
                name.clone()
            } else {
                format!("{}/{}", rel_path, name)
            };

            entries.push(DirEntry {
                name,
                path: child_rel,
                is_dir,
                size_bytes,
            });
        }
    }

    // Sort directories first, then alphabetically
    entries.sort_by(|a, b| {
        b.is_dir.cmp(&a.is_dir).then_with(|| a.name.cmp(&b.name))
    });

    Ok(entries)
}
