//! Headless CLI sync: run from systemd or terminal without GUI.

use super::helpers::*;
use super::sync_cmd::*;
use crate::config;
use std::fs;
use std::time::Instant;

pub fn run_sync_headless(config_path_override: Option<String>) -> i32 {
    let c = if let Some(path) = config_path_override {
        match config::load_config_from(std::path::Path::new(&path)) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("backsnap: Config-Fehler: {}", e);
                return 1;
            }
        }
    } else {
        cfg()
    };

    if let Err(e) = validate_sync_config(&c) {
        eprintln!("backsnap: Config-Validierung fehlgeschlagen: {}", e);
        return 1;
    }

    if let Some(parent) = std::path::Path::new(&c.sync.log_path).parent() {
        let _ = fs::create_dir_all(parent);
    }

    let _lock = match SyncLock::acquire() {
        Ok(l) => l,
        Err(e) => {
            eprintln!("backsnap: {}", e);
            sync_log(&c.sync.log_path, &format!("CLI FEHLER: {}", e));
            return 1;
        }
    };

    let start_time = Instant::now();
    rotate_log(&c.sync.log_path, c.sync.log_max_lines);

    println!("backsnap: Preflight-Check...");

    if !cmd_exists("rsync") {
        eprintln!("backsnap: rsync nicht installiert");
        return 1;
    }

    let ctx = match detect_sync_direction(&c) {
        Ok(ctx) => ctx,
        Err(e) => {
            eprintln!("backsnap: {}", e);
            sync_log(&c.sync.log_path, &format!("CLI FEHLER: {}", e));
            return 1;
        }
    };

    sync_log(
        &c.sync.log_path,
        &format!("=== Sync Start (CLI): {} ===", ctx.direction),
    );
    println!("backsnap: Richtung: {}", ctx.direction);

    let total_phases = c.sync.subvolumes.len() + if c.boot.sync_enabled { 1 } else { 0 };

    // ── Sync subvolumes ──
    for (i, sv) in c.sync.subvolumes.iter().enumerate() {
        let phase = i + 1;
        let mnt = format!("{}-{}", ctx.mount_base, sv.name);
        println!(
            "backsnap: [{}/{}] {} ({}) synchronisieren...",
            phase, total_phases, sv.name, sv.source
        );
        sync_log(
            &c.sync.log_path,
            &format!("Phase {}/{}: Sync {} ...", phase, total_phases, sv.source),
        );

        if let Err(e) = mount_subvol(&ctx.backup_dev, &mnt, &sv.subvol, &c.sync.mount_options) {
            eprintln!("backsnap: Mount-Fehler {}: {}", sv.subvol, e);
            sync_log(
                &c.sync.log_path,
                &format!("FEHLER mount {}: {}", sv.subvol, e),
            );
            return 1;
        }
        // RAII guard: unmount automatically even if the code below panics or returns early.
        let _umount_guard = AutoUmount(mnt.clone());

        let excludes_raw: Vec<String> = if sv.source == "/" {
            c.sync.system_excludes.clone()
        } else if sv.source == super::helpers::get_home_mountpoint() || sv.source == super::helpers::get_home_mountpoint().trim_end_matches('/') {
            let mut exc = c.sync.home_excludes.clone();
            if c.sync.extra_excludes_on_primary && ctx.is_primary_boot {
                exc.extend(c.sync.home_extra_excludes.clone());
            }
            exc
        } else {
            Vec::new()
        };

        let excludes = sanitize_excludes(&excludes_raw);
        if excludes.len() != excludes_raw.len() {
            println!(
                "backsnap: Excludes normalisiert: {} -> {} ({})",
                excludes_raw.len(),
                excludes.len(),
                sv.source
            );
            sync_log(
                &c.sync.log_path,
                &format!(
                    "Excludes normalisiert: {} -> {} ({})",
                    excludes_raw.len(),
                    excludes.len(),
                    sv.source
                ),
            );
        }

        let src = if sv.source.ends_with('/') {
            sv.source.clone()
        } else {
            format!("{}/", sv.source)
        };

        match run_rsync(&src, &format!("{}/", mnt), &excludes, sv.delete) {
            Ok(r) => {
                let stats: Vec<&str> = r
                    .stdout
                    .lines()
                    .filter(|l| l.contains("bytes") || l.contains("transferred"))
                    .collect();
                println!("backsnap: {} OK. {}", sv.name, stats.join(" | "));
                sync_log(
                    &c.sync.log_path,
                    &format!("{} OK. {}", sv.name, stats.join(" | ")),
                );
            }
            Err(e) => {
                // _umount_guard drops here automatically
                eprintln!("backsnap: Sync-Fehler {}: {}", sv.name, e);
                sync_log(
                    &c.sync.log_path,
                    &format!("FEHLER {}-Sync: {}", sv.name, e),
                );
                return 1;
            }
        }

        // ── Patch fstab on backup after syncing the root subvolume ──
        if sv.source == "/" {
            let backup_efi_dev = derive_efi_partition(&ctx.backup_dev);
            let primary_efi_dev = derive_efi_partition(
                &run_cmd("blkid", &["-U", &c.disks.primary_uuid]).stdout.trim().to_string(),
            );
            let backup_efi_uuid = get_partition_uuid(&backup_efi_dev);
            let primary_efi_uuid = get_partition_uuid(&primary_efi_dev);

            match patch_backup_fstab(
                &mnt,
                &c.disks.primary_uuid,
                &c.disks.backup_uuid,
                &primary_efi_uuid,
                &backup_efi_uuid,
                &c.sync.log_path,
            ) {
                Ok(()) => println!("backsnap: fstab-Patch OK."),
                Err(e) => {
                    eprintln!("backsnap: WARNUNG fstab-Patch: {}", e);
                    sync_log(&c.sync.log_path, &format!("WARNUNG fstab-Patch: {}", e));
                }
            }
        }

        // _umount_guard drops here at end of loop body
    }

    // ── Boot sync ──
    if c.boot.sync_enabled {
        println!(
            "backsnap: [{}/{}] Boot synchronisieren...",
            total_phases, total_phases
        );
        sync_log(
            &c.sync.log_path,
            &format!("Phase {}/{}: Sync /boot ...", total_phases, total_phases),
        );

        let backup_efi = derive_efi_partition(&ctx.backup_dev);
        let boot_mnt = BOOT_MOUNT;
        let _ = run_privileged("mkdir", &["-p", boot_mnt]);

        let mount_res = run_privileged("mount", &[&backup_efi, boot_mnt]);
        if mount_res.success {
            // RAII guard: unmounts boot_mnt when this if-block ends, even on early return.
            let _boot_guard = AutoUmount(boot_mnt.to_string());
            let boot_excludes = sanitize_excludes(&c.boot.excludes);
            if boot_excludes.len() != c.boot.excludes.len() {
                println!(
                    "backsnap: Boot-Excludes normalisiert: {} -> {}",
                    c.boot.excludes.len(),
                    boot_excludes.len()
                );
            }

            match run_rsync("/boot/", &format!("{}/", boot_mnt), &boot_excludes, false) {
                Ok(_) => {
                    println!("backsnap: Boot-Dateien OK.");
                    sync_log(&c.sync.log_path, "Boot-Dateien OK.");
                }
                Err(e) => {
                    println!("backsnap: WARNUNG Boot-Sync: {}", e);
                    sync_log(
                        &c.sync.log_path,
                        &format!("WARNUNG Boot-Sync: {}", e),
                    );
                }
            }

            match c.boot.bootloader_type.as_str() {
                "systemd-boot" => {
                    let bl_update = run_privileged("bootctl", &["update", &format!("--esp-path={}", boot_mnt), "--no-variables"]);
                    if bl_update.success {
                        println!("backsnap: Bootloader-Update (systemd-boot) OK.");
                        sync_log(&c.sync.log_path, "Bootloader-Update (systemd-boot) auf Backup-EFI OK.");
                    } else {
                        println!("backsnap: WARNUNG Bootloader-Update: {}", bl_update.stderr.trim());
                        sync_log(&c.sync.log_path, &format!("WARNUNG Bootloader-Update: {}", bl_update.stderr.trim()));
                    }
                }
                "grub" => {
                    let parent = derive_parent_disk(&backup_efi);
                    if !parent.is_empty() {
                        let arch = detect_efi_arch();
                        let grub_target = format!("--target={}-efi", arch);
                        let grub_install = run_privileged("grub-install", &[
                            &grub_target,
                            "--efi-directory", boot_mnt,
                            "--boot-directory", boot_mnt,
                            "--removable",
                            &parent,
                        ]);
                        if grub_install.success {
                            println!("backsnap: GRUB auf Backup-EFI installiert.");
                            sync_log(&c.sync.log_path, "GRUB auf Backup-EFI installiert.");
                        } else {
                            let grub2 = run_privileged("grub2-install", &[
                                &grub_target,
                                "--efi-directory", boot_mnt,
                                "--boot-directory", boot_mnt,
                                "--removable",
                                &parent,
                            ]);
                            if grub2.success {
                                println!("backsnap: GRUB2 auf Backup-EFI installiert.");
                                sync_log(&c.sync.log_path, "GRUB2 auf Backup-EFI installiert.");
                            } else {
                                println!("backsnap: WARNUNG GRUB-Install: {}", grub_install.stderr.trim());
                                sync_log(&c.sync.log_path, &format!("WARNUNG GRUB-Install: {}", grub_install.stderr.trim()));
                            }
                        }
                    }
                }
                _ => {
                    println!("backsnap: WARNUNG: Unbekannter Bootloader-Typ, Boot-Update übersprungen.");
                    sync_log(&c.sync.log_path, "WARNUNG: Unbekannter Bootloader-Typ, Boot-Update übersprungen.");
                }
            }

            match patch_backup_boot_entries(
                boot_mnt,
                &c.disks.primary_uuid,
                &c.disks.backup_uuid,
                &c.boot.bootloader_type,
                &c.disks.backup_label,
                &c.disks.primary_label,
                &c.sync.log_path,
            ) {
                Ok(()) => println!("backsnap: Boot-Entry-Patch OK."),
                Err(e) => {
                    eprintln!("backsnap: WARNUNG Boot-Entry-Patch: {}", e);
                    sync_log(&c.sync.log_path, &format!("WARNUNG Boot-Entry-Patch: {}", e));
                }
            }
        } else {
            println!(
                "backsnap: WARNUNG: Konnte EFI {} nicht mounten",
                backup_efi
            );
            sync_log(
                &c.sync.log_path,
                &format!(
                    "WARNUNG: Konnte Backup-EFI {} nicht mounten: {}",
                    backup_efi, mount_res.stderr
                ),
            );
        }
        // _boot_guard drops here (no-op if mount failed)
    }

    let elapsed = start_time.elapsed().as_secs();
    let duration_str = format_duration(elapsed);
    println!(
        "backsnap: Sync fertig: {} (Dauer: {})",
        ctx.direction, duration_str
    );
    sync_log(
        &c.sync.log_path,
        &format!(
            "=== Sync fertig (CLI): {} (Dauer: {}) ===",
            ctx.direction, duration_str
        ),
    );

    0
}
