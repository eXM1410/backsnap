//! Boot info & validation commands: EFI partition checks, entry parsing, kernel verification.

use super::helpers::*;
use super::sync_cmd::{derive_efi_partition, detect_efi_arch, efi_arch_suffix};
use crate::config::AppConfig;
use serde::{Deserialize, Serialize};
use std::fs;
use std::sync::Mutex;

// ─── Types ────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BootValidation {
    pub backup_efi_accessible: bool,
    pub bootloader_present: bool,
    pub entries_valid: bool,
    pub kernels_present: Vec<String>,
    pub kernels_missing: Vec<String>,
    pub entry_issues: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BootInfo {
    pub current_entry: String,
    pub bootloader_version: String,
    pub entries: Vec<BootEntryInfo>,
    pub backup_bootable: bool,
    pub backup_bootloader_version: Option<String>,
    pub booted_from: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BootEntryInfo {
    pub title: String,
    pub id: String,
    pub root_uuid: String,
    pub kernel: String,
    pub disk: String,
}

// ─── Boot Entry Parser ───────────────────────────────────────

fn parse_boot_entry(content: &str) -> (String, String, String) {
    let mut title = String::new();
    let mut root_uuid = String::new();
    let mut kernel = String::new();
    for line in content.lines() {
        let line = line.trim();
        if let Some(val) = line.strip_prefix("title ") {
            title = val.trim().to_string();
        } else if line.starts_with("linux ") || line.starts_with("linuxefi ") || line.starts_with("linux16 ") {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() > 1 {
                kernel = parts[1].trim_start_matches('/').to_string();
            }
            for part in parts {
                if let Some(uuid) = part.strip_prefix("root=UUID=") {
                    root_uuid = uuid.to_string();
                } else if let Some(uuid) = part.strip_prefix("root=/dev/disk/by-uuid/") {
                    root_uuid = uuid.to_string();
                }
            }
        } else if let Some(val) = line.strip_prefix("options ") {
            for part in val.split_whitespace() {
                if let Some(uuid) = part.strip_prefix("root=UUID=") {
                    root_uuid = uuid.to_string();
                } else if let Some(uuid) = part.strip_prefix("root=/dev/disk/by-uuid/") {
                    root_uuid = uuid.to_string();
                }
            }
        } else if line.starts_with("menuentry ") {
            if let Some(start) = line.find('\'').or_else(|| line.find('"')) {
                if let Some(end) = line[start + 1..].find(line.chars().nth(start).unwrap()) {
                    title = line[start + 1..start + 1 + end].to_string();
                }
            }
        }
    }
    (title, root_uuid, kernel)
}

fn classify_uuid(uuid: &str, c: &AppConfig) -> String {
    if uuid.is_empty() {
        "Unknown".to_string()
    } else if uuid == c.disks.primary_uuid {
        "Primary".to_string()
    } else if uuid == c.disks.backup_uuid {
        "Backup".to_string()
    } else {
        "Unknown".to_string()
    }
}

// ─── Cached Accessors ─────────────────────────────────────────

pub(crate) fn get_cached_boot_validation(backup_efi_dev: &str, c: &AppConfig) -> BootValidation {
    let cache = BOOT_VALIDATION_CACHE.get_or_init(|| Mutex::new(None));
    let mut guard = cache.lock().unwrap();
    if let Some(ref v) = *guard {
        return v.clone();
    }
    let v = validate_backup_boot(backup_efi_dev, c);
    *guard = Some(v.clone());
    v
}

pub(crate) fn get_cached_boot_info(c: &AppConfig) -> BootInfo {
    let cache = BOOT_INFO_CACHE.get_or_init(|| Mutex::new(None));
    let mut guard = cache.lock().unwrap();
    if let Some(ref info) = *guard {
        return info.clone();
    }
    let info = gather_boot_info(c);
    *guard = Some(info.clone());
    info
}

// ─── Boot Validation ──────────────────────────────────────────

fn validate_backup_boot(backup_efi_dev: &str, c: &AppConfig) -> BootValidation {
    if !validate_device_path(backup_efi_dev) {
        return BootValidation {
            backup_efi_accessible: false,
            bootloader_present: false,
            entries_valid: false,
            kernels_present: Vec::new(),
            kernels_missing: Vec::new(),
            entry_issues: vec![format!(
                "Ungültiger EFI-Device-Pfad: '{}'", backup_efi_dev
            )],
        };
    }

    let mnt = "/tmp/backsnap-boot-validate";
    let bl_type = c.boot.bootloader_type.as_str();
    let arch = detect_efi_arch();
    let suffix = efi_arch_suffix(&arch);
    let suffix_upper = suffix.to_uppercase();

    let bl_check = match bl_type {
        "grub" => format!(
            "(test -f {mnt}/EFI/BOOT/BOOT{SU}.EFI || test -f {mnt}/EFI/grub/grub{sl}.efi || test -d {mnt}/grub) && echo 'BL=yes' || echo 'BL=no'; \
             if [ -f {mnt}/grub/grub.cfg ]; then \
               awk '/^menuentry / {{print \"===ENTRY===\" $0; in_entry=1; next}} /^\\s*\\}}/ {{if(in_entry) {{print; in_entry=0; next}}}} in_entry {{print}}' {mnt}/grub/grub.cfg 2>/dev/null; \
             elif [ -f {mnt}/boot/grub/grub.cfg ]; then \
               awk '/^menuentry / {{print \"===ENTRY===\" $0; in_entry=1; next}} /^\\s*\\}}/ {{if(in_entry) {{print; in_entry=0; next}}}} in_entry {{print}}' {mnt}/boot/grub/grub.cfg 2>/dev/null; \
             fi",
            mnt = mnt, SU = suffix_upper, sl = suffix),
        _ => format!(
            "test -f {mnt}/EFI/systemd/systemd-boot{sl}.efi && echo 'BL=yes' || echo 'BL=no'; \
             for f in {mnt}/loader/entries/*.conf; do \
               [ -f \"$f\" ] && echo \"===ENTRY===$(basename \"$f\")\" && cat \"$f\"; \
             done",
            mnt = mnt, sl = suffix),
    };

    let script = format!(
        "mkdir -p {mnt} && \
         mount -o ro {dev} {mnt} 2>&1 && \
         echo '===MOUNTED===' && \
         {bl_check}; \
         echo '===KERNELS==='; \
         ls {mnt}/vmlinuz-* {mnt}/initramfs-* 2>/dev/null; \
         umount {mnt} 2>/dev/null; rmdir {mnt} 2>/dev/null; \
         true",
        mnt = mnt,
        dev = backup_efi_dev,
        bl_check = bl_check,
    );
    let result = run_privileged("sh", &["-c", &script]);
    let output = result.stdout;

    if !output.contains("===MOUNTED===") {
        return BootValidation {
            backup_efi_accessible: false,
            bootloader_present: false,
            entries_valid: false,
            kernels_present: Vec::new(),
            kernels_missing: Vec::new(),
            entry_issues: vec![format!(
                "Backup-EFI {} nicht mountbar: {}",
                backup_efi_dev,
                result.stderr.trim()
            )],
        };
    }

    let bootloader_present = output.contains("BL=yes");

    // Parse entries
    let mut entries: Vec<(String, String, String, String)> = Vec::new();
    let mut current_entry_id = String::new();
    let mut current_entry_content = String::new();
    for line in output.lines() {
        if let Some(name) = line.strip_prefix("===ENTRY===") {
            if !current_entry_id.is_empty() {
                let (title, uuid, kernel) = parse_boot_entry(&current_entry_content);
                entries.push((current_entry_id.clone(), title, uuid, kernel));
            }
            current_entry_id = name.trim_end_matches(".conf").to_string();
            current_entry_content.clear();
        } else if !current_entry_id.is_empty() && !line.starts_with("===") {
            current_entry_content.push_str(line);
            current_entry_content.push('\n');
        }
    }
    if !current_entry_id.is_empty() {
        let (title, uuid, kernel) = parse_boot_entry(&current_entry_content);
        entries.push((current_entry_id, title, uuid, kernel));
    }

    // Collect available kernel files
    let mut available_files: Vec<String> = Vec::new();
    let mut in_kernels = false;
    for line in output.lines() {
        if line.starts_with("===KERNELS===") {
            in_kernels = true;
            continue;
        }
        if line.starts_with("===") {
            in_kernels = false;
        }
        if in_kernels {
            let fname = line.rsplit('/').next().unwrap_or(line).trim();
            if !fname.is_empty() {
                available_files.push(fname.to_string());
            }
        }
    }

    let mut issues = Vec::new();
    let mut kernels_present = Vec::new();
    let mut kernels_missing = Vec::new();

    let backup_uuid = if get_boot_uuid() == c.disks.primary_uuid {
        &c.disks.backup_uuid
    } else {
        &c.disks.primary_uuid
    };

    for (id, _title, uuid, kernel) in &entries {
        if !uuid.is_empty() && uuid != backup_uuid {
            issues.push(format!(
                "{}: UUID {} zeigt nicht auf Backup-Disk (erwartet: {})",
                id, uuid, backup_uuid
            ));
        }
        if !kernel.is_empty() {
            let kernel_fname = kernel.trim_start_matches('/');
            if available_files.iter().any(|f| f == kernel_fname) {
                kernels_present.push(kernel.clone());
            } else {
                kernels_missing.push(kernel.clone());
                issues.push(format!("{}: Kernel '{}' fehlt auf Backup-EFI", id, kernel));
            }
        }
    }

    if !bootloader_present {
        issues.push(format!("{} Bootloader fehlt auf Backup-EFI", bl_type));
    }
    if entries.is_empty() {
        issues.push("Keine Boot-Entries auf Backup-EFI gefunden".to_string());
    }

    BootValidation {
        backup_efi_accessible: true,
        bootloader_present,
        entries_valid: issues.is_empty(),
        kernels_present,
        kernels_missing,
        entry_issues: issues,
    }
}

// ─── Boot Info Gathering ──────────────────────────────────────

fn gather_boot_info(c: &AppConfig) -> BootInfo {
    let boot_uuid = get_boot_uuid();
    let booted_from = if boot_uuid == c.disks.primary_uuid {
        "Primary".to_string()
    } else if boot_uuid == c.disks.backup_uuid {
        "Backup".to_string()
    } else {
        "Unknown".to_string()
    };

    let backup_efi = if !c.disks.backup_uuid.is_empty() {
        let other_uuid = if boot_uuid == c.disks.primary_uuid {
            &c.disks.backup_uuid
        } else {
            &c.disks.primary_uuid
        };
        let blkid = run_cmd("blkid", &["-U", other_uuid]);
        if blkid.success {
            Some(derive_efi_partition(blkid.stdout.trim()))
        } else {
            None
        }
    } else {
        None
    };
    let backup_efi = backup_efi.filter(|dev| validate_device_path(dev));

    let bl_type = c.boot.bootloader_type.as_str();
    let arch = detect_efi_arch();
    let suffix = efi_arch_suffix(&arch);
    let suffix_upper = suffix.to_uppercase();

    let backup_section = if let Some(ref efi_dev) = backup_efi {
        let backup_bl_check = match bl_type {
            "grub" => format!(
                "(test -f $MNT/EFI/BOOT/BOOT{SU}.EFI || test -f $MNT/EFI/grub/grub{sl}.efi || test -d $MNT/grub) && echo 'BACKUP_BL=yes' || echo 'BACKUP_BL=no'; \
                 grub_ver=$(strings $MNT/EFI/grub/grub{sl}.efi 2>/dev/null | grep -oP 'GRUB \\K[0-9.]+' | head -1); \
                 [ -n \"$grub_ver\" ] && echo \"BACKUP_BL_VER=GRUB $grub_ver\" || echo 'BACKUP_BL_VER='; \
                 if [ -f $MNT/grub/grub.cfg ]; then \
                   awk '/^menuentry / {{print \"===BENTRY===\" $0; in_entry=1; next}} /^\\s*\\}}/ {{if(in_entry) {{print; in_entry=0; next}}}} in_entry {{print}}' $MNT/grub/grub.cfg 2>/dev/null; \
                 elif [ -f $MNT/boot/grub/grub.cfg ]; then \
                   awk '/^menuentry / {{print \"===BENTRY===\" $0; in_entry=1; next}} /^\\s*\\}}/ {{if(in_entry) {{print; in_entry=0; next}}}} in_entry {{print}}' $MNT/boot/grub/grub.cfg 2>/dev/null; \
                 fi",
                SU = suffix_upper, sl = suffix),
            _ => format!(
                "test -f $MNT/EFI/systemd/systemd-boot{sl}.efi && echo 'BACKUP_BL=yes' || echo 'BACKUP_BL=no'; \
                 strings $MNT/EFI/systemd/systemd-boot{sl}.efi 2>/dev/null | grep -oP 'systemd-boot \\K[0-9.]+' | head -1 | sed 's/^/BACKUP_BL_VER=/'; \
                 for f in $MNT/loader/entries/*.conf; do \
                   [ -f \"$f\" ] && echo \"===BENTRY===$(basename \"$f\")\" && cat \"$f\"; \
                 done",
                sl = suffix),
        };
        format!(
            "echo '===BACKUP==='; \
             MNT=/tmp/backsnap-boot-check; \
             mkdir -p $MNT && mount -o ro {dev} $MNT 2>&1; \
             if mountpoint -q $MNT 2>/dev/null; then \
               {bl_check}; \
               umount $MNT 2>/dev/null; rmdir $MNT 2>/dev/null; \
             else \
               echo 'BACKUP_MOUNT=fail'; \
             fi",
            dev = efi_dev,
            bl_check = backup_bl_check,
        )
    } else {
        String::new()
    };

    let primary_section = match bl_type {
        "grub" => format!(
            "grub-install --version 2>/dev/null || grub2-install --version 2>/dev/null; \
             echo '===ENTRIES==='; \
             if [ -f /boot/grub/grub.cfg ]; then \
               awk '/^menuentry / {{print \"===ENTRY===\" $0; in_entry=1; next}} /^\\s*\\}}/ {{if(in_entry) {{print; in_entry=0; next}}}} in_entry {{print}}' /boot/grub/grub.cfg 2>/dev/null; \
             elif [ -f /boot/grub2/grub.cfg ]; then \
               awk '/^menuentry / {{print \"===ENTRY===\" $0; in_entry=1; next}} /^\\s*\\}}/ {{if(in_entry) {{print; in_entry=0; next}}}} in_entry {{print}}' /boot/grub2/grub.cfg 2>/dev/null; \
             fi"),
        _ => "bootctl status 2>/dev/null | head -20; \
              echo '===ENTRIES==='; \
              for f in /boot/loader/entries/*.conf; do \
                [ -f \"$f\" ] && echo \"===ENTRY===$(basename \"$f\")\" && cat \"$f\"; \
              done".to_string(),
    };

    let script = format!(
        "{primary}; \
         {backup}",
        primary = primary_section,
        backup = backup_section,
    );

    let result = run_privileged("sh", &["-c", &script]);
    let output = result.stdout;

    // Parse bootctl status
    let mut current_entry = String::new();
    let mut bootloader_version = String::new();
    for line in output.lines() {
        let trimmed = line.trim();
        if current_entry.is_empty() {
            if let Some(val) = trimmed.strip_prefix("Current Entry:") {
                current_entry = val.trim().to_string();
            }
        }
        if bootloader_version.is_empty() {
            if let Some(val) = trimmed.strip_prefix("Product:") {
                bootloader_version = val.trim().to_string();
            }
        }
    }
    if current_entry.is_empty() {
        current_entry = fs::read_to_string("/proc/cmdline")
            .unwrap_or_default()
            .split_whitespace()
            .find(|p| p.starts_with("BOOT_IMAGE="))
            .map(|p| p.trim_start_matches("BOOT_IMAGE=").to_string())
            .unwrap_or_else(|| "unknown".to_string());
    }

    // Parse active boot entries
    let mut entries = Vec::new();
    let mut cur_id = String::new();
    let mut cur_content = String::new();
    let mut in_entries = false;
    for line in output.lines() {
        if line.starts_with("===ENTRIES===") {
            in_entries = true;
            continue;
        }
        if line.starts_with("===BACKUP===") {
            break;
        }
        if !in_entries {
            continue;
        }
        if let Some(name) = line.strip_prefix("===ENTRY===") {
            if !cur_id.is_empty() {
                let (title, root_uuid, kernel) = parse_boot_entry(&cur_content);
                let disk = classify_uuid(&root_uuid, c);
                entries.push(BootEntryInfo { title, id: cur_id.clone(), root_uuid, kernel, disk });
            }
            cur_id = name.trim_end_matches(".conf").to_string();
            cur_content.clear();
        } else if !cur_id.is_empty() {
            cur_content.push_str(line);
            cur_content.push('\n');
        }
    }
    if !cur_id.is_empty() {
        let (title, root_uuid, kernel) = parse_boot_entry(&cur_content);
        let disk = classify_uuid(&root_uuid, c);
        entries.push(BootEntryInfo { title, id: cur_id, root_uuid, kernel, disk });
    }

    // Parse backup info
    let backup_bootable;
    let backup_bl_version;
    if output.contains("===BACKUP===") {
        let has_bl = output.contains("BACKUP_BL=yes");
        let bl_ver = output.lines()
            .find_map(|l| l.strip_prefix("BACKUP_BL_VER="))
            .filter(|v| !v.is_empty())
            .map(|v| {
                if v.to_lowercase().starts_with("grub") {
                    v.to_string()
                } else {
                    format!("systemd-boot {}", v)
                }
            });

        let mut in_backup = false;
        let mut bcur_id = String::new();
        let mut bcur_content = String::new();
        let mut has_backup_entries = false;
        for line in output.lines() {
            if line.starts_with("===BACKUP===") {
                in_backup = true;
                continue;
            }
            if !in_backup {
                continue;
            }
            if let Some(name) = line.strip_prefix("===BENTRY===") {
                if !bcur_id.is_empty() {
                    let (title, root_uuid, kernel) = parse_boot_entry(&bcur_content);
                    let disk = classify_uuid(&root_uuid, c);
                    entries.push(BootEntryInfo { title, id: bcur_id.clone(), root_uuid, kernel, disk });
                    has_backup_entries = true;
                }
                bcur_id = name.trim_end_matches(".conf").to_string();
                bcur_content.clear();
            } else if !bcur_id.is_empty()
                && !line.starts_with("BACKUP_BL=")
                && !line.starts_with("BACKUP_BL_VER=")
                && !line.starts_with("BACKUP_MOUNT=")
            {
                bcur_content.push_str(line);
                bcur_content.push('\n');
            }
        }
        if !bcur_id.is_empty() {
            let (title, root_uuid, kernel) = parse_boot_entry(&bcur_content);
            let disk = classify_uuid(&root_uuid, c);
            entries.push(BootEntryInfo { title, id: bcur_id, root_uuid, kernel, disk });
            has_backup_entries = true;
        }

        backup_bootable = has_bl && has_backup_entries;
        backup_bl_version = bl_ver;
    } else {
        backup_bootable = false;
        backup_bl_version = None;
    }

    BootInfo {
        current_entry,
        bootloader_version,
        entries,
        backup_bootable,
        backup_bootloader_version: backup_bl_version,
        booted_from,
    }
}

// ─── Tauri Command ────────────────────────────────────────────

#[tauri::command]
pub async fn get_boot_info() -> Result<BootInfo, String> {
    tokio::task::spawn_blocking(|| {
        let c = cfg();
        Ok(get_cached_boot_info(&c))
    })
    .await
    .map_err(|e| format!("Boot-Info thread panicked: {}", e))?
}
