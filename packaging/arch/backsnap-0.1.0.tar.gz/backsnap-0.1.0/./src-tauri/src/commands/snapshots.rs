//! Snapper snapshot commands: list, create, delete, diff, subvolumes.

use super::helpers::*;

#[tauri::command]
pub async fn get_subvolumes() -> Result<Vec<SubvolumeInfo>, String> {
    tokio::task::spawn_blocking(|| {
        let result = run_privileged("btrfs", &["subvolume", "list", "-t", "/"]);
        if !result.success {
            return Err(format!("btrfs subvolume list: {}", result.stderr));
        }

        let mut subvols = Vec::new();
        for line in result.stdout.lines().skip(2) {
            let cols: Vec<&str> = line.split_whitespace().collect();
            if cols.len() >= 4 {
                subvols.push(SubvolumeInfo {
                    id: cols[0].to_string(),
                    gen: cols[1].to_string(),
                    top_level: cols[2].to_string(),
                    path: cols[3..].join(" "),
                });
            }
        }
        Ok(subvols)
    })
    .await
    .map_err(|e| format!("Subvolume-Thread panicked: {}", e))?
}

#[tauri::command]
pub async fn get_snapshots(config: String) -> Result<Vec<Snapshot>, String> {
    validate_config(&config)?;
    tokio::task::spawn_blocking(move || {
        let result = run_cmd("snapper", &["--csvout", "-c", &config, "list"]);
        if !result.success {
            return Err(format!("snapper error: {}", result.stderr));
        }

        let mut snapshots = Vec::new();
        let mut lines = result.stdout.lines();
        let header = lines.next().unwrap_or("");
        let headers: Vec<&str> = header.split(',').collect();

        let idx = |name: &str| headers.iter().position(|h| h.trim() == name);
        let i_num = idx("number").or_else(|| idx("#")).unwrap_or(0);
        let i_type = idx("type").unwrap_or(1);
        let i_pre = idx("pre-number").unwrap_or(2);
        let i_date = idx("date").unwrap_or(3);
        let i_user = idx("user").unwrap_or(4);
        let i_cleanup = idx("cleanup").unwrap_or(5);
        let i_desc = idx("description").unwrap_or(6);

        for line in lines {
            let cols: Vec<&str> = line.splitn(headers.len().max(1), ',').collect();
            if cols.len() < 4 { continue; }
            let get = |i: usize| cols.get(i).map(|s| s.trim().to_string()).unwrap_or_default();
            let id = get(i_num).parse::<u32>().unwrap_or(0);
            if id == 0 { continue; }
            snapshots.push(Snapshot {
                id,
                snap_type: get(i_type),
                pre_id: get(i_pre).parse::<u32>().ok(),
                date: get(i_date),
                user: get(i_user),
                cleanup: get(i_cleanup),
                description: get(i_desc),
            });
        }
        snapshots.reverse();
        Ok(snapshots)
    })
    .await
    .map_err(|e| format!("Snapshot-Thread panicked: {}", e))?
}

#[tauri::command]
pub async fn create_snapshot(config: String, description: String) -> Result<CommandResult, String> {
    validate_config(&config)?;
    validate_description(&description)?;
    tokio::task::spawn_blocking(move || {
        Ok(run_cmd("snapper", &["-c", &config, "create", "-d", &description]))
    })
    .await
    .map_err(|e| format!("Snapshot-Thread panicked: {}", e))?
}

#[tauri::command]
pub async fn delete_snapshot(config: String, id: u32) -> Result<CommandResult, String> {
    validate_config(&config)?;
    tokio::task::spawn_blocking(move || {
        let id_str = id.to_string();
        Ok(run_privileged("snapper", &["-c", &config, "delete", &id_str]))
    })
    .await
    .map_err(|e| format!("Snapshot-Thread panicked: {}", e))?
}

#[tauri::command]
pub async fn get_snapper_diff(config: String, id: u32) -> Result<String, String> {
    validate_config(&config)?;
    tokio::task::spawn_blocking(move || {
        let id_str = id.to_string();
        let range = format!("{}..0", id_str);
        let result = run_cmd("snapper", &["-c", &config, "status", &range]);
        if result.success { Ok(result.stdout) } else { Err(result.stderr) }
    })
    .await
    .map_err(|e| format!("Diff-Thread panicked: {}", e))?
}
