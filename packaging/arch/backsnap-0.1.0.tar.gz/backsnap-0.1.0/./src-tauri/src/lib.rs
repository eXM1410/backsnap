mod commands;
mod config;
mod scanner;
mod sysmon;
mod util;

use commands::*;
use tauri::{
    menu::{MenuBuilder, MenuItemBuilder},
    tray::TrayIconEvent,
    Manager, WindowEvent,
};
use tauri_plugin_autostart::MacosLauncher;
use tauri_plugin_window_state::{AppHandleExt as _, Builder as WindowStateBuilder, StateFlags};

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_autostart::init(
            MacosLauncher::LaunchAgent,
            Some(vec![]),
        ))
        .plugin(
            WindowStateBuilder::default()
                .with_state_flags(StateFlags::all())
                .with_denylist(&["widget"])
                .build(),
        )
        .setup(|app| {
            let log_level = if cfg!(debug_assertions) {
                log::LevelFilter::Info
            } else {
                log::LevelFilter::Warn
            };
            app.handle().plugin(
                tauri_plugin_log::Builder::default()
                    .level(log_level)
                    .build(),
            )?;

            // ── Tray Menu ──────────────────────────────────────────
            let handle = app.handle().clone();
            let show = MenuItemBuilder::with_id("show", "Backsnap öffnen").build(&handle)?;
            let widget = MenuItemBuilder::with_id("widget", "Widget ein/aus").build(&handle)?;
            let quit = MenuItemBuilder::with_id("quit", "Beenden").build(&handle)?;
            let menu = MenuBuilder::new(&handle)
                .item(&show)
                .separator()
                .item(&widget)
                .separator()
                .item(&quit)
                .build()?;

            if let Some(tray) = app.tray_by_id("main-tray") {
                tray.set_menu(Some(menu))?;
                tray.on_menu_event(move |app_handle, event| {
                    match event.id().as_ref() {
                        "show" => {
                            if let Some(w) = app_handle.get_webview_window("main") {
                                let _ = w.show();
                                let _ = w.unminimize();
                                let _ = w.set_focus();
                            }
                        }
                        "widget" => {
                            toggle_widget(app_handle);
                        }
                        "quit" => {
                            app_handle.exit(0);
                        }
                        _ => {}
                    }
                });
                tray.on_tray_icon_event(|tray, event| {
                    if let TrayIconEvent::Click { button: tauri::tray::MouseButton::Left, .. } = event {
                        let app_handle = tray.app_handle();
                        if let Some(w) = app_handle.get_webview_window("main") {
                            let _ = w.show();
                            let _ = w.unminimize();
                            let _ = w.set_focus();
                        }
                    }
                });
            }

            Ok(())
        })
        .on_window_event(|window, event| {
            if window.label() == "main" {
                if let WindowEvent::CloseRequested { api, .. } = event {
                    api.prevent_close();
                    // Persist size/position even when we keep running in the tray.
                    let _ = window.app_handle().save_window_state(StateFlags::all());
                    let _ = window.hide();
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            get_system_status,
            get_snapshots,
            create_snapshot,
            delete_snapshot,
            run_sync,
            get_sync_status,
            get_sync_log,
            get_timer_config,
            set_timer_enabled,
            rollback_snapshot,
            get_snapper_diff,
            get_btrfs_usage,
            get_health,
            get_subvolumes,
            get_config,
            get_activity_log,
            save_config_cmd,
            detect_disks,
            reset_config,
            scan_excludes,
            scan_cleanup,
            cancel_scan,
            delete_cleanup_paths,
            get_cleanup_dir_contents,
            install_timer,
            uninstall_timer,
            get_system_monitor,
            get_boot_info,
            verify_backup,
            get_integration_status,
            install_system_integration,
            uninstall_system_integration,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

fn toggle_widget(app_handle: &tauri::AppHandle) {
    if let Some(w) = app_handle.get_webview_window("widget") {
        if w.is_visible().unwrap_or(false) {
            let _ = w.hide();
        } else {
            let _ = w.show();
        }
    } else {
        // Create the widget window
        let builder = tauri::WebviewWindowBuilder::new(
            app_handle,
            "widget",
            tauri::WebviewUrl::App("/widget".into()),
        )
        .title("Backsnap Widget")
        .inner_size(320.0, 420.0)
        .resizable(true)
        .decorations(false)
        .transparent(true)
        .always_on_bottom(true)
        .skip_taskbar(true);

        match builder.build() {
            Ok(_w) => {
                log::info!("Widget window created");
            }
            Err(e) => {
                log::error!("Failed to create widget window: {}", e);
            }
        }
    }
}

/// Headless sync for systemd/CLI — no GUI, no Tauri runtime
pub fn run_sync_cli(config_path: Option<String>) -> i32 {
    commands::run_sync_headless(config_path)
}
