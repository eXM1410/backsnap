//! Configuration data structures — serialized to/from TOML.

use serde::{Deserialize, Serialize};

use super::boot::detect_bootloader;
use crate::util::safe_cmd;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct AppConfig {
    pub disks: DiskConfig,
    pub sync: SyncConfig,
    pub boot: BootConfig,
    pub snapper: SnapperConfig,
    pub rollback: RollbackConfig,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct DiskConfig {
    pub primary_uuid: String,
    pub primary_label: String,
    pub backup_uuid: String,
    pub backup_label: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SyncConfig {
    pub timer_unit: String,
    pub service_unit: String,
    pub log_path: String,
    pub log_max_lines: usize,
    pub mount_options: String,
    pub mount_base: String,
    pub subvolumes: Vec<SubvolSync>,
    pub system_excludes: Vec<String>,
    pub home_excludes: Vec<String>,
    pub home_extra_excludes: Vec<String>,
    pub extra_excludes_on_primary: bool,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SubvolSync {
    pub name: String,
    pub subvol: String,
    pub source: String,
    pub delete: bool,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct BootConfig {
    pub sync_enabled: bool,
    #[serde(default = "default_bootloader_type")]
    pub bootloader_type: String,
    pub excludes: Vec<String>,
}

fn default_bootloader_type() -> String {
    detect_bootloader()
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct SnapperConfig {
    pub expected_configs: Vec<String>,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct RollbackConfig {
    pub max_broken_backups: usize,
    pub recovery_label: String,
    pub root_subvol: String,
    #[serde(default = "default_root_config")]
    pub root_config: String,
}

fn default_root_config() -> String {
    let configs = safe_cmd("snapper", &["list-configs", "--columns", "config"])
        .map(|o| {
            String::from_utf8_lossy(&o.stdout)
                .lines()
                .skip(2)
                .map(|l| l.trim().to_string())
                .filter(|l| !l.is_empty())
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();
    super::detect::detect_snapper_root_config(&configs)
}
