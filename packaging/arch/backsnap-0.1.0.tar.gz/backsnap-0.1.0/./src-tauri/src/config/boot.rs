//! Bootloader detection (systemd-boot, grub, unknown).

use crate::util::safe_cmd;

/// Detect which bootloader is installed: systemd-boot, grub, or unknown.
///
/// NOTE: `bootctl status` may exit with code 1 on Arch due to permission errors
/// on /boot files, but stdout still contains "systemd-boot". We check stdout
/// regardless of exit code.
pub fn detect_bootloader() -> String {
    // 1. bootctl status — fastest and most reliable
    if let Some(o) = safe_cmd("bootctl", &["status"]) {
        let out = String::from_utf8_lossy(&o.stdout);
        if out.contains("systemd-boot") || out.contains("Boot Loader Specification") {
            return "systemd-boot".to_string();
        }
    }

    // 2. Filesystem checks
    if std::path::Path::new("/boot/EFI/systemd/systemd-bootx64.efi").exists()
        || std::path::Path::new("/boot/efi/EFI/systemd/systemd-bootx64.efi").exists()
        || std::path::Path::new("/efi/EFI/systemd/systemd-bootx64.efi").exists()
        || std::path::Path::new("/boot/loader/loader.conf").exists()
    {
        return "systemd-boot".to_string();
    }
    if std::path::Path::new("/boot/grub/grub.cfg").exists()
        || std::path::Path::new("/boot/grub2/grub.cfg").exists()
    {
        return "grub".to_string();
    }

    "unknown".to_string()
}
