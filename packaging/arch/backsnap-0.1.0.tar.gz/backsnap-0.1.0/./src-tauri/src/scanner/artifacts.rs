//! Phase 3: Build artifact scanner.
//!
//! Finds build artifacts (node_modules, target/, .venv, etc.) inside
//! project directories. Uses native parallel FS walking instead of `find`.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use rayon::prelude::*;

use super::types::*;
use super::walker;
use crate::util::format_size;

/// Scan for build artifacts inside project directories.
///
/// Finds well-known artifact directories (node_modules, target/debug, .venv, etc.)
/// up to 5 levels deep, computes their sizes in parallel, and returns results
/// for anything ≥ 10 MB.
pub fn scan_project_artifacts(
    home: &Path, 
    mut on_found: impl FnMut(ScannedExclude) + Send,
    on_progress: &(impl Fn(&std::path::Path) + Sync + Send)
) {
    // Build artifact dir names → (reason, required_parent)
    let artifact_info: HashMap<&str, (&str, Option<&str>)> = [
        ("node_modules", ("Node.js Abhängigkeiten (npm/pnpm/yarn install regeneriert)", None)),
        (".venv", ("Python Virtual Environment (python -m venv regeneriert)", None)),
        ("venv", ("Python Virtual Environment", None)),
        ("__pycache__", ("Python Bytecode Cache", None)),
        ("debug", ("Rust Debug Build-Artefakte (cargo build regeneriert)", Some("target"))),
        ("release", ("Rust Release Build-Artefakte", Some("target"))),
        (".next", ("Next.js Build-Output", None)),
        ("dist", ("Build Output", None)),
        (".gradle", ("Gradle Projekt-Cache", None)),
        (".dart_tool", ("Dart/Flutter Tool Cache", None)),
        (".pub-cache", ("Dart pub Package Cache", None)),
        ("intermediates", ("Android Build-Artefakte", Some("build"))),
    ]
    .into_iter()
    .collect();

    let names: Vec<&str> = artifact_info.keys().copied().collect();

    on_progress(std::path::Path::new("Suche nach Projekt-Ordnern (node_modules, target, etc.)..."));

    // Native parallel find — replaces `find $home -maxdepth 5 -type d \( -name … \)`
    let found = walker::find_dirs_by_name(home, &names, 5, Some(on_progress));

    // Filter and build candidates
    let mut candidates: Vec<(PathBuf, String, &str)> = Vec::new();
    for abs in found {
        if !abs.exists() {
            continue;
        }

        let dir_name = abs
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_default();

        let (reason, required_parent) = match artifact_info.get(dir_name.as_str()) {
            Some(info) => *info,
            None => continue,
        };

        // For patterns like "target/debug", verify parent matches
        if let Some(parent_name) = required_parent {
            let actual_parent = abs
                .parent()
                .and_then(|p| p.file_name())
                .map(|n| n.to_string_lossy().to_string())
                .unwrap_or_default();
            if actual_parent != parent_name {
                continue;
            }
        }

        let rel = abs
            .strip_prefix(home)
            .map(|p| p.to_string_lossy().to_string())
            .unwrap_or_default();
        if rel.is_empty() {
            continue;
        }

        // For target/debug → display as target/debug; for intermediates → build/intermediates
        let display_rel = if required_parent.is_some() {
            if let Some(parent_path) = abs.parent() {
                parent_path
                    .strip_prefix(home)
                    .map(|p| p.to_string_lossy().to_string())
                    .unwrap_or(rel.clone())
            } else {
                rel.clone()
            }
        } else {
            rel.clone()
        };

        candidates.push((abs, display_rel, reason));
    }

    // Parallel size computation using rayon (via walker)
    let indexed: Vec<(usize, PathBuf)> = candidates
        .iter()
        .enumerate()
        .map(|(i, (abs, _, _))| (i, abs.clone()))
        .collect();

    let (tx, rx) = std::sync::mpsc::channel();
    rayon::scope(|s| {
        s.spawn(|_| {
            indexed.into_par_iter().for_each_with(tx, |tx, (idx, path)| {
                if crate::scanner::CANCEL_SCAN.load(std::sync::atomic::Ordering::Relaxed) {
                    return;
                }
                on_progress(&path);
                let size = walker::dir_size(&path, Some(on_progress));
                let _ = tx.send((idx, size));
            });
        });

        for (i, size) in rx {
            if crate::scanner::CANCEL_SCAN.load(std::sync::atomic::Ordering::Relaxed) {
                break;
            }
            if size < 10 * 1024 * 1024 {
                continue; // Skip tiny ones (< 10 MB)
            }
            let (_abs, rel, reason) = &candidates[i];
            on_found(ScannedExclude {
                path: rel.clone(),
                category: ExcludeCategory::BuildArtifact,
                reason: format!("{} ({})", reason, format_size(size)),
                size_bytes: size,
                size_human: format_size(size),
                auto_exclude: true,
            });
        }
    });
}
