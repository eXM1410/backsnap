#!/bin/sh
# backsnap — Deinstallation
set -e

GREEN='\033[0;32m'; CYAN='\033[0;36m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { printf "${GREEN}  ✓${NC} %s\n" "$1"; }
info() { printf "${CYAN}  →${NC} %s\n" "$1"; }
err()  { printf "${RED}  ✗${NC} %s\n" "$1"; exit 1; }

[ "$(id -u)" -eq 0 ] || err "Bitte als Root ausführen: sudo sh uninstall.sh"

info "Stoppe und entferne systemd-Timer..."
systemctl disable --now backsnap-sync.timer 2>/dev/null || true
systemctl stop backsnap-sync.service 2>/dev/null || true
systemctl disable --now backsnap-rapl-perms.service 2>/dev/null || true
rm -f /etc/systemd/system/backsnap-sync.timer
rm -f /etc/systemd/system/backsnap-sync.service
rm -f /etc/systemd/system/backsnap-rapl-perms.service
systemctl daemon-reload 2>/dev/null || true
ok "Systemd-Units entfernt"

info "Entferne Binary..."
rm -f /usr/local/bin/backsnap
rm -f /usr/bin/backsnap
ok "Binary entfernt"

if [ -n "$SUDO_USER" ] && [ "$SUDO_USER" != "root" ]; then
	USER_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
	if [ -n "$USER_HOME" ] && [ -d "$USER_HOME" ]; then
		rm -f "$USER_HOME/.config/autostart/backsnap.desktop"
		ok "Autostart entfernt ($SUDO_USER)"
	fi
fi

info "Entferne Desktop-Eintrag und Icon..."
rm -f /usr/share/applications/backsnap.desktop
rm -f /usr/share/icons/hicolor/128x128/apps/backsnap.png
gtk-update-icon-cache /usr/share/icons/hicolor 2>/dev/null || true
update-desktop-database /usr/share/applications 2>/dev/null || true
ok "Desktop-Eintrag und Icon entfernt"

info "Entferne Polkit-Regel..."
rm -f /etc/polkit-1/rules.d/50-backsnap.rules
ok "Polkit-Regel entfernt"

info "Entferne Pacman-Hook..."
rm -f /etc/pacman.d/hooks/00-backsnap-pre.hook
ok "Pacman-Hook entfernt"

printf "\n${GREEN}backsnap vollständig deinstalliert.${NC}\n"
printf "  Konfiguration bleibt erhalten unter: ~/.config/backsnap/config.toml\n"
printf "  Logs bleiben erhalten unter: /var/log/backsnap-sync.log\n\n"
