#!/bin/sh
# backsnap — Arch Linux System-Integration
# Verwendung: sudo sh install.sh [--no-build]
set -e

BINARY_NAME="backsnap"
INSTALL_BIN="/usr/local/bin/backsnap"
ICON_DST="/usr/share/icons/hicolor/128x128/apps/backsnap.png"
DESKTOP_DST="/usr/share/applications/backsnap.desktop"
POLKIT_DST="/etc/polkit-1/rules.d/50-backsnap.rules"
HOOK_DIR="/etc/pacman.d/hooks"
HOOK_DST="$HOOK_DIR/00-backsnap-pre.hook"

AUTOSTART_REL=".config/autostart/backsnap.desktop"

# ── Farben ────────────────────────────────────────────────────
GREEN='\033[0;32m'; CYAN='\033[0;36m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { printf "${GREEN}  ✓${NC} %s\n" "$1"; }
info() { printf "${CYAN}  →${NC} %s\n" "$1"; }
err()  { printf "${RED}  ✗${NC} %s\n" "$1"; exit 1; }

# ── Root-Check ────────────────────────────────────────────────
[ "$(id -u)" -eq 0 ] || err "Bitte als Root ausführen: sudo sh install.sh"

# ── Verzeichnis ───────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# ── Build (optional überspringen) ────────────────────────────
if [ "$1" != "--no-build" ]; then
  info "Baue Release-Binary..."
  if ! command -v cargo >/dev/null 2>&1; then
    err "cargo nicht gefunden. Rust installieren oder --no-build verwenden."
  fi
  # Als normaler Nutzer bauen (nicht als root)
  if [ -n "$SUDO_USER" ]; then
    su -c "cd '$SCRIPT_DIR' && npm run tauri build -- --no-bundle 2>&1" "$SUDO_USER" \
      || err "Build fehlgeschlagen"
  else
    npm run tauri build -- --no-bundle 2>&1 || err "Build fehlgeschlagen"
  fi
  ok "Build abgeschlossen"
fi

# ── Binary ────────────────────────────────────────────────────
RELEASE_BIN="$SCRIPT_DIR/src-tauri/target/release/$BINARY_NAME"
[ -f "$RELEASE_BIN" ] || err "Binary nicht gefunden: $RELEASE_BIN\nFühre zuerst 'npm run tauri build' aus."

info "Installiere Binary nach $INSTALL_BIN..."
cp "$RELEASE_BIN" "$INSTALL_BIN"
chmod 755 "$INSTALL_BIN"
ok "Binary installiert"

# ── Icon ──────────────────────────────────────────────────────
info "Installiere Icon..."
mkdir -p "$(dirname "$ICON_DST")"
cp "$SCRIPT_DIR/src-tauri/icons/128x128.png" "$ICON_DST"
gtk-update-icon-cache /usr/share/icons/hicolor 2>/dev/null || true
ok "Icon installiert"

# ── .desktop ─────────────────────────────────────────────────
info "Installiere Desktop-Eintrag..."
cat > "$DESKTOP_DST" << EOF
[Desktop Entry]
Name=backsnap
GenericName=Backup Manager
Comment=Btrfs System Backup mit Snapper und rsync
Exec=$INSTALL_BIN
Icon=backsnap
Terminal=false
Type=Application
Categories=System;Utility;
Keywords=backup;btrfs;snapper;sync;
StartupWMClass=backsnap
EOF
update-desktop-database /usr/share/applications 2>/dev/null || true
ok "Desktop-Eintrag installiert"

# ── Autostart (pro User) ─────────────────────────────────────
if [ -n "$SUDO_USER" ] && [ "$SUDO_USER" != "root" ]; then
  USER_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
  if [ -n "$USER_HOME" ] && [ -d "$USER_HOME" ]; then
    AUTOSTART_DST="$USER_HOME/$AUTOSTART_REL"
    info "Aktiviere Autostart für User '$SUDO_USER'..."
    mkdir -p "$(dirname "$AUTOSTART_DST")"
    cat > "$AUTOSTART_DST" << EOF
[Desktop Entry]
Type=Application
Name=Backsnap
Comment=System Backup & Recovery Manager
Exec=$INSTALL_BIN
Icon=backsnap
Terminal=false
Categories=System;Utility;
StartupNotify=true
X-GNOME-Autostart-enabled=true
EOF
    chown "$SUDO_USER":"$SUDO_USER" "$AUTOSTART_DST" 2>/dev/null || true
    ok "Autostart aktiviert ($AUTOSTART_DST)"
  else
    info "Autostart übersprungen (Home-Verzeichnis für '$SUDO_USER' nicht gefunden)"
  fi
else
  info "Autostart übersprungen (kein SUDO_USER)"
fi

# ── Polkit-Regel ─────────────────────────────────────────────
info "Installiere Polkit-Regel (kein Passwort-Prompt für wheel-Gruppe)..."
cat > "$POLKIT_DST" << EOF
// backsnap — wheel-Mitglieder dürfen backsnap ohne Passwort privilegiert ausführen
polkit.addRule(function(action, subject) {
    if (action.id == "org.freedesktop.policykit.exec" &&
        action.lookup("program") == "$INSTALL_BIN" &&
        subject.isInGroup("wheel")) {
        return polkit.Result.YES;
    }
});
EOF
ok "Polkit-Regel installiert"

# ── Pacman-Hook ───────────────────────────────────────────────
info "Installiere Pacman-Hook (Pre-Update Snapshot)..."
mkdir -p "$HOOK_DIR"
cat > "$HOOK_DST" << EOF
# backsnap — automatischer Snapper-Snapshot vor jedem Pacman-Update
[Trigger]
Operation = Upgrade
Operation = Install
Operation = Remove
Type = Package
Target = *

[Action]
Description = backsnap: Erstelle Pre-Update Snapshot...
When = PreTransaction
Exec = /usr/bin/snapper -c root create --type=pre --cleanup-algorithm=number --print-number --description="pacman update"
Depends On = pacman
EOF
ok "Pacman-Hook installiert"

# ── Fertig ────────────────────────────────────────────────────
printf "\n${GREEN}backsnap erfolgreich installiert!${NC}\n"
printf "  Binary:      %s\n" "$INSTALL_BIN"
printf "  Desktop:     %s\n" "$DESKTOP_DST"
printf "  Icon:        %s\n" "$ICON_DST"
printf "  Polkit:      %s\n" "$POLKIT_DST"
printf "  Pacman-Hook: %s\n" "$HOOK_DST"
printf "\n  Timer über die App einrichten: backsnap → Sync-Zeitplan → Installieren\n\n"
