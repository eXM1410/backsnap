#!/bin/sh
set -e

# Build a pacman package from the current working tree.
# Usage:
#   cd packaging/arch && ./build-local.sh

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT_DIR"

# Extract version from src-tauri/tauri.conf.json (fallback to 0.1.0)
PKGVER="$(python -c 'import json; import pathlib; p=pathlib.Path("src-tauri/tauri.conf.json");
try:
  print(json.loads(p.read_text()).get("version","0.1.0"))
except Exception:
  print("0.1.0")
')"

PKGNAME="backsnap"
TARBALL_DIR="$ROOT_DIR/packaging/arch"
TARBALL="$TARBALL_DIR/${PKGNAME}-${PKGVER}.tar.gz"

echo "→ Creating source tarball: $TARBALL"
mkdir -p "$TARBALL_DIR"

# Create a clean tarball for makepkg (exclude build artifacts)
# shellcheck disable=SC2086
tar \
  --exclude-vcs \
  --exclude='node_modules' \
  --exclude='dist' \
  --exclude='src-tauri/target' \
  --exclude='src-tauri/target/*' \
  --exclude='packaging/arch/src' \
  --exclude='packaging/arch/pkg' \
  --exclude='packaging/arch/*.tar.gz' \
  --exclude='packaging/arch/*.pkg.tar.*' \
  -czf "$TARBALL" \
  --transform "s#^#${PKGNAME}-${PKGVER}/#" \
  .

cd "$TARBALL_DIR"

# Keep PKGBUILD version in sync (simple replace)
if [ -f PKGBUILD ]; then
  sed -i "s/^pkgver=.*/pkgver=${PKGVER}/" PKGBUILD
fi

echo "→ Building package with makepkg"
makepkg -f

echo "✓ Done. Install with: sudo pacman -U ${PKGNAME}-${PKGVER}-*.pkg.tar.zst"
